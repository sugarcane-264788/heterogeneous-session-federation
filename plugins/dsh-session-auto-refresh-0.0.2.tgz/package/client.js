/**
 * dsh-session-auto-refresh — Client half.
 *
 * What it does
 * ------------
 * The sidebar session list is a snapshot the Client keeps locally: it only
 * changes when something in *this* page mutates the catalog. A Session started
 * by another process, another browser tab, or a Host-side plugin therefore
 * stays invisible until the page is reloaded. This plugin closes that gap:
 *
 *   every 15s
 *     -> read the Host catalog            ctx.remote.session.list({})
 *     -> read the sidebar snapshot ids    ctx.sessions.list.getSnapshot().ids
 *     -> only if the two disagree         ctx.sessions.refresh()
 *
 * `ctx.sessions.refresh()` is the one supported "re-pull the list" entry point
 * (`ISessions.refresh`, implemented by the session-controller's `refreshList()`
 * as `this.remote.session.list({})` + a rebuild of the local summaries). It
 * rebuilds the list snapshot only: no page reload, no reconnect, and the
 * currently open Session is untouched.
 *
 * Everything runs inside `ctx.effect` / `ctx.slots`, so disabling or removing
 * the bundle tears the timer and the button down with it.
 */
window.__ModuleLoader__.load({
  id: '@local/session-auto-refresh',
  factory(require) {
    const React = require('react');
    const h = React.createElement;
    const { useState, useEffect, useRef } = React;

    /** Locale namespace owned by this plugin. */
    // M131 备注：locale 命名空间与样式 id 都是历史遗留标识，与包名无耦合——
    // 改名（@local/* -> dsh-*）时不要顺手改，改了会丢已有翻译与既有样式覆盖。
    const NS = 'sessionAutoRefresh';
    /** Poll cadence for the catalog-vs-snapshot comparison. */
    const POLL_INTERVAL_MS = 15000;
    /** First probe a little after boot, so a stale list is repaired quickly. */
    const FIRST_PROBE_DELAY_MS = 2000;
    /** After this many consecutive probe failures, stop comparing and just refresh. */
    const PROBE_FAILURE_LIMIT = 3;
    const LOG_PREFIX = '[session-auto-refresh]';
    const STYLE_ID = 'session-auto-refresh-style';

    const en = {
      aria: 'Refresh session list',
      label: 'Refresh',
      busy: 'Refreshing...',
      added: 'Refreshed: {count} new session(s)',
      none: 'Refreshed: no new sessions',
      failed: 'Refresh failed: {message}',
    };

    const zh = {
      aria: '刷新会话列表',
      label: '刷新',
      busy: '正在刷新…',
      added: '已刷新：新增 {count} 个会话',
      none: '已刷新：没有新会话',
      failed: '刷新失败：{message}',
    };

    const CSS = `
.dsr-refresh-btn {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  gap: 6px;
  box-sizing: border-box;
  height: 28px;
  padding: 0 8px;
  border: 1px solid var(--dsw-alias-border-l1);
  border-radius: 6px;
  background: transparent;
  color: var(--dsw-alias-label-secondary);
  font: inherit;
  font-size: 12px;
  line-height: 1;
  cursor: pointer;
  white-space: nowrap;
  transition: background-color 120ms ease, color 120ms ease, border-color 120ms ease;
}
.dsr-refresh-btn:hover {
  background: var(--dsw-alias-bg-layer-2);
  color: var(--dsw-alias-label-primary);
}
.dsr-refresh-btn:focus-visible {
  outline: 2px solid var(--dsw-alias-brand-primary);
  outline-offset: 1px;
}
.dsr-refresh-btn[disabled] {
  cursor: progress;
  opacity: 0.65;
}
.dsr-refresh-btn--busy > svg {
  animation: dsr-refresh-spin 900ms linear infinite;
}
.dsr-refresh-btn--wide {
  width: 100%;
}
.dsr-refresh-btn--rail {
  width: 28px;
  padding: 0;
}
@keyframes dsr-refresh-spin {
  from { transform: rotate(0deg); }
  to { transform: rotate(360deg); }
}
.dsr-refresh-notice {
  position: fixed;
  right: 16px;
  bottom: 16px;
  z-index: 60;
  max-width: 320px;
  padding: 8px 12px;
  border: 1px solid var(--dsw-alias-border-l1);
  border-radius: 8px;
  background: var(--dsw-alias-bg-overlay);
  color: var(--dsw-alias-label-primary);
  font-size: 12px;
  line-height: 1.5;
  box-shadow: 0 6px 20px rgb(0 0 0 / 12%);
}
.dsr-refresh-notice--error {
  color: var(--dsw-alias-state-error-primary);
}
`;

    /** Refresh glyph, drawn with currentColor so it follows the variable-driven styling. */
    function RefreshGlyph({ size }) {
      return h(
        'svg',
        {
          width: size,
          height: size,
          viewBox: '0 0 16 16',
          fill: 'none',
          stroke: 'currentColor',
          strokeWidth: 1.5,
          strokeLinecap: 'round',
          strokeLinejoin: 'round',
          'aria-hidden': 'true',
          focusable: 'false',
        },
        h('path', { d: 'M13.5 8a5.5 5.5 0 1 1-1.61-3.89' }),
        h('path', { d: 'M13.5 2.2V5.5h-3.3' }),
      );
    }

    /** Error text that survives a non-Error rejection. */
    function errText(error) {
      if (error && typeof error.message === 'string' && error.message) return error.message;
      return String(error);
    }

    /**
     * The manual refresh button, rendered into `sidebar.footer.action`.
     * The notice below is shown for *manual* clicks only; the automatic poll
     * never surfaces UI, it only writes a console.debug line.
     */
    function RefreshButton({ t, wide, refreshSessions }) {
      const [busy, setBusy] = useState(false);
      const [notice, setNotice] = useState(null);
      const timer = useRef(null);
      const alive = useRef(true);

      const clearTimer = () => {
        if (timer.current !== null) {
          clearTimeout(timer.current);
          timer.current = null;
        }
      };

      const show = (text, isError) => {
        clearTimer();
        setNotice({ text, isError: Boolean(isError) });
        timer.current = setTimeout(() => {
          timer.current = null;
          if (alive.current) setNotice(null);
        }, 5000);
      };

      useEffect(() => {
        alive.current = true;
        return () => {
          alive.current = false;
          clearTimer();
        };
      }, []);

      const onClick = async () => {
        if (busy) return;
        setBusy(true);
        try {
          const result = await refreshSessions();
          console.debug(`${LOG_PREFIX} manual refresh ok total=${result.total} added=${result.added}`);
          if (result.added > 0) show(t('added', { count: result.added }), false);
          else show(t('none'), false);
        } catch (error) {
          console.debug(`${LOG_PREFIX} manual refresh failed error=${errText(error)}`);
          show(t('failed', { message: errText(error) }), true);
        } finally {
          if (alive.current) setBusy(false);
        }
      };

      const className = [
        'dsr-refresh-btn',
        wide ? 'dsr-refresh-btn--wide' : 'dsr-refresh-btn--rail',
        busy ? 'dsr-refresh-btn--busy' : '',
      ]
        .filter(Boolean)
        .join(' ');

      return h(
        React.Fragment,
        null,
        h(
          'button',
          {
            type: 'button',
            className,
            disabled: busy,
            title: t('aria'),
            'aria-label': t('aria'),
            onClick,
          },
          h(RefreshGlyph, { size: 14 }),
          wide ? h('span', null, busy ? t('busy') : t('label')) : null,
        ),
        notice
          ? h(
              'div',
              {
                className: notice.isError ? 'dsr-refresh-notice dsr-refresh-notice--error' : 'dsr-refresh-notice',
                role: 'status',
              },
              notice.text,
            )
          : null,
      );
    }

    return {
      // 'timer' supplies the managed timers (ctx.interval / ctx.timeout).
      // 'remote' + 'remote.session' supply the Host catalog probe. The Client
      // context is a traceable guard proxy: `remote.session` is only readable
      // once 'remote.session' is itself declared (the same pair the official
      // session controller declares), and it is not reachable through
      // ctx.get('remote').
      inject: ['slots', 'locale', 'sessions', 'timer', 'remote', 'remote.session'],

      apply(ctx) {
        ctx.effect(() => ctx.locale.register(NS, { en, zh }), 'session-auto-refresh: dictionaries');

        ctx.effect(() => {
          if (typeof document === 'undefined' || document.getElementById(STYLE_ID)) return () => {};
          const el = document.createElement('style');
          el.id = STYLE_ID;
          el.textContent = CSS;
          document.head.appendChild(el);
          return () => {
            if (el.parentNode) el.parentNode.removeChild(el);
          };
        }, 'session-auto-refresh: styles');

        /** Session ids the sidebar snapshot currently believes in. */
        const readSidebarIds = () => {
          const snapshot = ctx.sessions.list.getSnapshot();
          const ids = snapshot && Array.isArray(snapshot.ids) ? snapshot.ids : [];
          return new Set(ids);
        };

        /**
         * Session ids the Host catalog currently holds, read straight from the
         * remote service so the sidebar snapshot cannot contaminate the answer.
         * Throws when the probe is unavailable or the call fails.
         */
        const readHostIds = async () => {
          const remote = ctx.remote;
          const namespace = remote && remote.session;
          const list = namespace && namespace.list;
          if (typeof list !== 'function') {
            throw new Error("client service 'remote.session.list' is not available");
          }
          const result = await list.call(namespace, {});
          if (!result || result.ok !== true) {
            const failure = result && result.error;
            throw new Error(failure ? `${failure.code || 'error'}: ${failure.message || 'session.list failed'}` : 'session.list returned no result');
          }
          const value = result.value || {};
          const items = Array.isArray(value.items) ? value.items : [];
          const ids = new Set();
          for (const item of items) {
            const id = item && item.sessionId;
            if (typeof id === 'string' && id) ids.add(id);
          }
          return ids;
        };

        /** Re-pull the Host-authoritative list and report how many ids appeared. */
        const refreshSessions = async () => {
          const before = readSidebarIds();
          await ctx.sessions.refresh();
          const after = readSidebarIds();
          let added = 0;
          for (const id of after) if (!before.has(id)) added += 1;
          return { added, total: after.size };
        };

        // ------------------------------------------------------------------
        // Automatic catalog poll
        // ------------------------------------------------------------------
        let compareMode = true;
        let probeFailures = 0;
        let inFlight = false;

        const poll = async () => {
          if (inFlight) return;
          inFlight = true;
          try {
            const sidebar = readSidebarIds();

            if (compareMode) {
              let host = null;
              try {
                host = await readHostIds();
                probeFailures = 0;
              } catch (error) {
                probeFailures += 1;
                const message = errText(error);
                if (probeFailures < PROBE_FAILURE_LIMIT) {
                  console.debug(`${LOG_PREFIX} poll probe-failed attempt=${probeFailures} sidebar=${sidebar.size} error=${message}`);
                  return;
                }
                compareMode = false;
                console.debug(
                  `${LOG_PREFIX} poll degraded: host catalog probe unavailable after ${probeFailures} attempts (${message}); refreshing unconditionally every ${POLL_INTERVAL_MS}ms`,
                );
              }

              if (host) {
                let missing = 0;
                let extra = 0;
                for (const id of host) if (!sidebar.has(id)) missing += 1;
                for (const id of sidebar) if (!host.has(id)) extra += 1;
                if (missing === 0 && extra === 0) {
                  console.debug(`${LOG_PREFIX} poll host=${host.size} sidebar=${sidebar.size} gap=0 action=none`);
                  return;
                }
                await ctx.sessions.refresh();
                console.debug(
                  `${LOG_PREFIX} poll host=${host.size} sidebar=${sidebar.size} gap=${missing + extra} action=refresh added=${missing} removed=${extra}`,
                );
                return;
              }
            }

            await ctx.sessions.refresh();
            console.debug(`${LOG_PREFIX} poll host=? sidebar=${sidebar.size} gap=? action=refresh mode=blind`);
          } catch (error) {
            console.debug(`${LOG_PREFIX} poll failed error=${errText(error)}`);
          } finally {
            inFlight = false;
          }
        };

        // All timing goes through the Client timer service (`timer` is injected
        // above), so the scheduler is owned by the plugin fiber and disappears
        // with it. Bare setInterval/setTimeout are deliberately not used.
        ctx.effect(() => {
          if (typeof ctx.interval !== 'function' || typeof ctx.timeout !== 'function') {
            console.debug(`${LOG_PREFIX} timer service unavailable (ctx.interval/ctx.timeout missing); automatic catalog refresh not started`);
            return () => {};
          }
          const tick = () => {
            void poll();
          };
          const disposers = [
            ctx.timeout(tick, FIRST_PROBE_DELAY_MS),
            ctx.interval(tick, POLL_INTERVAL_MS),
          ];
          console.debug(`${LOG_PREFIX} scheduler started first=${FIRST_PROBE_DELAY_MS}ms every=${POLL_INTERVAL_MS}ms`);
          return () => {
            for (const dispose of disposers) {
              try {
                dispose();
              } catch (error) {
                console.debug(`${LOG_PREFIX} timer dispose failed error=${errText(error)}`);
              }
            }
          };
        }, 'session-auto-refresh: catalog poll');

        // ------------------------------------------------------------------
        // Manual button, kept as the visible counterpart of the poll.
        // ------------------------------------------------------------------
        ctx.slots.inject('sidebar.footer.action', () =>
          ctx.slots.register(
            {
              name: 'sidebar.footer.action',
              id: 'session-auto-refresh',
              order: 41,
              locale: NS,
              inject: () => ({ refreshSessions }),
            },
            RefreshButton,
          ),
        );
      },
    };
  },
});
