/**
 * Host half of dsh-session-auto-refresh.
 *
 * This bundle needs no Host capability at all. Everything it does runs in the
 * browser against services the Client composition already provides:
 *
 *   - `ctx.remote.session.list({})` (optional probe) reads the Host Session
 *     catalog without touching the sidebar snapshot;
 *   - `ctx.sessions.refresh()` re-pulls that catalog through
 *     `@deepseek-ai/dsh-api-session-controller` and rebuilds the sidebar list
 *     snapshot only (no page reload, no reconnect, no current-Session change).
 *
 * The Client half in client.js owns both the poll and the manual button.
 */
export function apply() {}
