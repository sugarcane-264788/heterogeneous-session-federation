# dsh-session-auto-refresh

DSH Web 侧栏的会话目录自动刷新插件：每 15 秒比对「Host 上的 Session 目录」与「侧栏快照」，**只在两者不一致时**调用 `ctx.sessions.refresh()` 重拉列表，因此被别的进程 / 别的标签页 / Host 侧插件唤醒出来的 Session 无需 F12 就会出现；同时保留侧栏底部一个手动「刷新」按钮（`sidebar.footer.action`）用于对照。

- 只重拉列表快照：不重载页面、不重连、不动当前会话。
- 无缺口时不发 RPC 刷新，只写一行 `console.debug`。
- 探针不可用（组合里没有 `remote.session.list`）时退化为定时无条件刷新，并在控制台说明原因。
- 暴露的表单/文案走 Client locale 服务（`en` / `zh`），颜色全部取自 `--dsw-alias-*` 变量。

## 安装（Web profile）

```bash
export DSH_HOME='D:\USTB\AI-Workspace\build\sandbox-home'   # 换成目标 DSH_HOME
dsh plugin --profile sandbox add 'D:\USTB\AI-Workspace\build\ui-session-auto-refresh'
```

`dsh plugin add` 会把包名写进该 profile 的 `dsh.profile.bundles`，下次启动 Web 时
`dsh.bundle.patch` 里的 `insert` 生效。重启 Web（或重开页面）后在侧栏底部可见「刷新」按钮，
浏览器控制台可见 `[session-auto-refresh] scheduler started ...`。

> 注意：`dsh plugin` 内部直接 `execa("pnpm", ...)`，pnpm 必须在 PATH 上；若报
> `'pnpm' 不是内部或外部命令`，把 DSH 自带的 pnpm 包一层入口脚本并前置到 PATH 即可
> （例如 `D:\DSH\dsh-runtimes\dsh-primary-runtime\dependencies\pnpm\bin\pnpm.mjs`）。

## 回滚

```bash
export DSH_HOME='D:\USTB\AI-Workspace\build\sandbox-home'
dsh plugin --profile sandbox remove dsh-session-auto-refresh
```

或直接编辑 `$DSH_HOME/profiles/<name>/package.json`，把 `dsh-session-auto-refresh`
从 `dsh.profile.bundles` 与 `dependencies` 中删掉，再重启 Web。插件自身不留任何宿主状态，
回滚无需清理数据。
