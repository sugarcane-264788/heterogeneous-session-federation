# -*- coding: utf-8 -*-
"""kbhub_server.py —— 最小可用的 stdio MCP 服务器（kbhub 0.1.0）。

传输：newline-delimited JSON-RPC 2.0（每行一条完整 JSON，消息内不能有裸换行）。
    - 从 stdin 逐行读，往 stdout 逐行写，UTF-8，ensure_ascii=False。
    - stdout 只允许出现协议消息；所有日志一律走 stderr。
    - 任何单条请求出异常都不退出进程；stdin EOF 正常退出（exit 0）。

工具（4 个；前三个只读，最后一个是写盘探针）：
    kbhub_status       读 mailbox.json + _索引.md 行数
    kbhub_inbox_list   列某个信箱目录的文件清单（最多 50 条）
    kbhub_check        跑 工具\\kb\\kb_check.py（cwd=协作库根），回退出码 + 最后 5 行
    kbhub_probe_write  往 build\\hub-probe.txt / hub-probe-log.tsv 写时间戳（关键实验）

只用标准库。不改协作库任何文件（kb_check.py 本身只读，实测无写操作）。
"""

import json
import os
import subprocess
import sys
import time
import traceback

# ---------------------------------------------------------------- 路径常量
AW = os.environ.get('KBHUB_AW') or ''            # 库根一律由装载层 env.KBHUB_AW 传下来（install.py 写入）；这里不猜路径
KB = os.path.join(AW, '协作库') if AW else ''
MAILBOX_JSON = os.path.join(KB, '40-协作', '_machine', 'mailbox.json')
MSG_DIR = os.path.join(KB, '40-协作', '_消息')
INDEX_MD = os.path.join(KB, '_索引.md')
CHECK_PY = os.path.join(AW, '工具', 'kb', 'kb_check.py')
BUILD_DIR = os.path.join(AW, 'build')
PROBE_TXT = os.path.join(BUILD_DIR, 'hub-probe.txt')
PROBE_TSV = os.path.join(BUILD_DIR, 'hub-probe-log.tsv')

# 箱名：mailbox.json 用英文键，目录用中文名（与 工具\mailbox\mailbox.py 的 BOXES 一致）
BOX_ORDER = ['main', 'email', 'learn', 'prog', 'sched', 'other', 'kb']
BOX_ALIAS = {
    'main': '主对话',
    'email': '邮件会话',
    'learn': '学习主管',
    'prog': '程设',
    'sched': '课表',
    'other': '其他课',
    'kb': '协作库维护',
}
CN_TO_ALIAS = {v: k for k, v in BOX_ALIAS.items()}
MAX_LIST = 50
CHECK_TIMEOUT = 180  # kb_check.py 实测约 16s，留足余量


def log(msg):
    """日志只写 stderr，绝不污染 stdout 协议流。"""
    try:
        sys.stderr.write('[kbhub] %s\n' % msg)
        sys.stderr.flush()
    except Exception:
        pass


# ---------------------------------------------------------------- 通用小工具
def _err(e):
    return '%s: %s' % (type(e).__name__, e)


def _read_text(path):
    with open(path, 'r', encoding='utf-8', errors='replace') as f:
        return f.read()


def _resolve_box(name):
    """箱名归一化：接受中文目录名、英文键、被 trim 的空白。非法返回 (None, 提示)。"""
    raw = (name or '').strip()
    if not raw:
        return None, '缺少参数 box。可用：' + '、'.join(BOX_ALIAS[k] for k in BOX_ORDER)
    if raw in BOX_ALIAS:                       # main / email ...
        return BOX_ALIAS[raw], BOX_ALIAS[raw]
    if raw in CN_TO_ALIAS:                     # 主对话 / 邮件会话 ...
        return raw, raw
    return None, '未知信箱 %r。可用：%s（英文键：%s）' % (
        raw,
        '、'.join(BOX_ALIAS[k] for k in BOX_ORDER),
        '/'.join(BOX_ORDER),
    )


# ---------------------------------------------------------------- 工具实现
def tool_status(args):
    """无参数。返回协作库现状：total_unread、各箱未读 + 目录文件数、_索引.md 行数。"""
    out = ['协作库：%s' % KB]

    total = None
    boxes = {}
    generated = None
    if os.path.isfile(MAILBOX_JSON):
        try:
            mb = json.loads(_read_text(MAILBOX_JSON))
            total = mb.get('total_unread')
            boxes = mb.get('boxes') or {}
            generated = mb.get('generated_at')
        except Exception as e:
            out.append('mailbox.json 读取失败：%s' % _err(e))
    else:
        out.append('mailbox.json 不存在：%s' % MAILBOX_JSON)

    out.append('total_unread：%s' % ('（无）' if total is None else total))
    if generated:
        out.append('快照生成时间：%s' % generated)

    out.append('')
    out.append('%-12s %-8s %-8s %-8s %s' % ('箱名', '键', '未读/总', '目录文件', '目录'))
    for key in BOX_ORDER:
        cn = BOX_ALIAS[key]
        b = boxes.get(key) or {}
        unread = b.get('unread', '-')
        tot = b.get('total', '-')
        d = os.path.join(MSG_DIR, cn)
        nfiles = '-'
        if os.path.isdir(d):
            try:
                nfiles = sum(1 for x in os.listdir(d) if os.path.isfile(os.path.join(d, x)))
            except Exception as e:
                nfiles = 'E:' + _err(e)
        else:
            d = '（缺目录）'
        out.append('%-12s %-8s %-8s %-8s %s' % (cn, key, '%s/%s' % (unread, tot), nfiles, d))

    # mailbox.json 里没登记的箱目录（如 已处理）也报一下，别假装看不见
    known_cn = set(BOX_ALIAS.values())
    extras = []
    if os.path.isdir(MSG_DIR):
        try:
            for x in sorted(os.listdir(MSG_DIR)):
                p = os.path.join(MSG_DIR, x)
                if os.path.isdir(p) and x not in known_cn:
                    n = sum(1 for y in os.listdir(p) if os.path.isfile(os.path.join(p, y)))
                    extras.append('%s(%d)' % (x, n))
        except Exception as e:
            out.append('列出 _消息 失败：%s' % _err(e))
    if extras:
        out.append('')
        out.append('其它目录：' + '、'.join(extras))

    out.append('')
    if os.path.isfile(INDEX_MD):
        try:
            t = _read_text(INDEX_MD)
            out.append('_索引.md：%d 行，%d 字节' % (len(t.splitlines()), len(t.encode('utf-8'))))
        except Exception as e:
            out.append('_索引.md 读取失败：%s' % _err(e))
    else:
        out.append('_索引.md 不存在：%s' % INDEX_MD)

    return '\n'.join(out), False


def tool_inbox_list(args):
    """参数 box（中文箱名或英文键）。列该箱文件：文件名 + 字节数，最多 50 条。"""
    cn, why = _resolve_box((args or {}).get('box'))
    if cn is None:
        return why, True                       # 参数错误：isError=true，如实说明
    d = os.path.join(MSG_DIR, cn)
    if not os.path.isdir(d):
        return '信箱目录不存在：%s' % d, True

    rows = []
    for name in os.listdir(d):
        p = os.path.join(d, name)
        if not os.path.isfile(p):
            continue
        try:
            size = os.path.getsize(p)
        except Exception:
            size = -1
        rows.append((name, size))
    rows.sort(key=lambda r: r[0], reverse=True)   # 文件名是时间戳前缀，倒序 = 新→旧

    shown = rows[:MAX_LIST]
    alias = CN_TO_ALIAS.get(cn, '?')
    head = '箱：%s（%s）  共 %d 个文件，返回 %d 条%s' % (
        cn, alias, len(rows), len(shown), '（已截断到 %d）' % MAX_LIST if len(rows) > MAX_LIST else '')
    lines = [head, '目录：%s' % d, '', '%-60s %10s' % ('文件名', '字节')]
    for name, size in shown:
        lines.append('%-60s %10s' % (name, size if size >= 0 else 'ERR'))
    if not rows:
        lines.append('（空箱）')
    return '\n'.join(lines), False


def tool_check(args):
    """无参数。cwd=协作库根，跑 python ..\\工具\\kb\\kb_check.py，回退出码 + 最后 5 行输出。"""
    if not os.path.isfile(CHECK_PY):
        return '自检脚本不存在：%s' % CHECK_PY, True
    env = os.environ.copy()
    env['PYTHONIOENCODING'] = 'utf-8'
    t0 = time.time()
    try:
        p = subprocess.run(
            [sys.executable, CHECK_PY],
            cwd=KB,
            stdin=subprocess.DEVNULL,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            timeout=CHECK_TIMEOUT,
            env=env,
        )
    except subprocess.TimeoutExpired:
        return 'kb_check.py 超时（>%ds）：%s' % (CHECK_TIMEOUT, CHECK_PY), True
    except Exception as e:
        return 'kb_check.py 启动失败：%s' % _err(e), True

    dt = time.time() - t0
    out = (p.stdout or b'').decode('utf-8', 'replace')
    err = (p.stderr or b'').decode('utf-8', 'replace')
    tail = [x for x in out.splitlines() if x.strip()][-5:]
    parts = [
        'exit code：%d' % p.returncode,
        '耗时：%.1fs' % dt,
        '脚本：%s' % CHECK_PY,
        '（判定：0=全过，非 0=有问题）',
        '',
        '最后 5 行输出 ↓',
    ]
    parts.extend(tail if tail else ['（无输出）'])
    if err.strip():
        parts.append('')
        parts.append('stderr 尾部 ↓')
        parts.extend([x for x in err.splitlines() if x.strip()][-5:])
    return '\n'.join(parts), p.returncode != 0


def tool_probe_write(args):
    """无参数。关键实验：在被挂载的服务进程里真的写盘。

    写 <工作区>\\build\\hub-probe.txt（一行时间戳，覆盖）
    并追加一行到 hub-probe-log.tsv。异常一律捕获并如实返回，绝不假装成功。
    """
    ts = time.strftime('%Y-%m-%dT%H:%M:%S%z')
    payload = {'wrote': False, 'path': PROBE_TXT, 'error': '', 'ts': ts, 'pid': os.getpid()}
    try:
        os.makedirs(BUILD_DIR, exist_ok=True)
        with open(PROBE_TXT, 'w', encoding='utf-8', newline='\n') as f:
            f.write(ts + '\n')
        with open(PROBE_TSV, 'a', encoding='utf-8', newline='\n') as f:
            f.write('%s\tpid=%d\tok\n' % (ts, os.getpid()))
        # 不信内存里的成功：先 stat 再说写了
        st = os.stat(PROBE_TXT)
        if st.st_size <= 0:
            raise IOError('写入后文件大小为 0：%s' % PROBE_TXT)
        payload['wrote'] = True
        payload['bytes'] = st.st_size
        payload['path'] = PROBE_TXT
        payload['log'] = PROBE_TSV
    except Exception as e:
        payload['wrote'] = False
        payload['error'] = _err(e)
        log('probe_write FAILED: %s' % payload['error'])
        return json.dumps(payload, ensure_ascii=False, indent=2), True
    log('probe_write OK -> %s (%d bytes)' % (PROBE_TXT, payload['bytes']))
    return json.dumps(payload, ensure_ascii=False, indent=2), False


# ---------------------------------------------------------------- 工具表 + schema
TOOLS = {
    'kbhub_status': tool_status,
    'kbhub_inbox_list': tool_inbox_list,
    'kbhub_check': tool_check,
    'kbhub_probe_write': tool_probe_write,
}

_NO_ARGS = {'type': 'object', 'properties': {}}
TOOL_LIST = [
    {
        'name': 'kbhub_status',
        'description': '读协作库现状：mailbox.json 的 total_unread、各箱未读/文件数、_索引.md 行数。只读，无参数。',
        'inputSchema': dict(_NO_ARGS),
    },
    {
        'name': 'kbhub_inbox_list',
        'description': '列某个信箱目录的文件清单（文件名 + 字节数，最多 50 条，新→旧）。只读。',
        'inputSchema': {
            'type': 'object',
            'properties': {
                'box': {
                    'type': 'string',
                    'description': '箱名：主对话/邮件会话/学习主管/程设/课表/其他课/协作库维护，或英文键 main/email/learn/prog/sched/other/kb',
                }
            },
            'required': ['box'],
        },
    },
    {
        'name': 'kbhub_check',
        'description': '在协作库根目录跑 python ..\\工具\\kb\\kb_check.py（13 项自检），返回退出码 + 最后 5 行输出。只读，无参数。',
        'inputSchema': dict(_NO_ARGS),
    },
    {
        'name': 'kbhub_probe_write',
        'description': '写盘探针：往 build\\hub-probe.txt 写一行时间戳，并追加到 build\\hub-probe-log.tsv。返回 {"wrote","path","error"}。验证「写盘在服务进程里」是否成立。',
        'inputSchema': dict(_NO_ARGS),
    },
]
TOOL_NAMES = [t['name'] for t in TOOL_LIST]


# ---------------------------------------------------------------- JSON-RPC 分发
def _result(id_, result):
    return {'jsonrpc': '2.0', 'id': id_, 'result': result}


def _error(id_, code, message, data=None):
    e = {'code': code, 'message': message}
    if data is not None:
        e['data'] = data
    return {'jsonrpc': '2.0', 'id': id_, 'error': e}


def _text_result(text, is_error=False):
    return {'content': [{'type': 'text', 'text': text}], 'isError': bool(is_error)}


def handle_tools_call(params):
    """tools/call：按 name 分发；工具内部异常一律转成 isError=true，不外抛。"""
    if not isinstance(params, dict):
        return _text_result('tools/call 的 params 必须是对象', True)
    name = params.get('name')
    args = params.get('arguments')
    if args is None:
        args = {}
    if not isinstance(args, dict):
        return _text_result('arguments 必须是对象，收到 %s' % type(args).__name__, True)
    if not name:
        return _text_result('缺少 params.name。可用工具：%s' % ', '.join(TOOL_NAMES), True)
    fn = TOOLS.get(name)
    if fn is None:
        return _text_result('未知工具 %r。可用工具：%s' % (name, ', '.join(TOOL_NAMES)), True)
    try:
        text, is_err = fn(args)
    except Exception as e:                     # 兜底：工具炸了也不许把进程带走
        log('tool %s raised: %s' % (name, _err(e)))
        text = '工具 %s 执行异常：%s\n%s' % (name, _err(e), traceback.format_exc())
        is_err = True
    if not isinstance(text, str):
        text = str(text)
    return _text_result(text, is_err)


def handle(msg):
    """处理一条消息。返回要回写的对象，或 None（通知不回包）。"""
    if not isinstance(msg, dict):
        return _error(None, -32600, 'Invalid Request: 顶层必须是 JSON 对象')
    mid = msg.get('id', None)
    method = msg.get('method')
    is_notification = ('id' not in msg) or (mid is None)

    if not isinstance(method, str):
        return None if is_notification else _error(mid, -32600, 'Invalid Request: 缺少 method')

    try:
        if method == 'initialize':
            if is_notification:                # 正常客户端会带 id；没 id 就别乱回包
                return None
            return _result(mid, {
                'protocolVersion': '2024-11-05',
                'capabilities': {'tools': {}},
                'serverInfo': {'name': 'kbhub', 'version': '0.1.0'},
            })
        if method in ('notifications/initialized', 'notifications/cancelled',
                      'notifications/roots/list_changed', 'notifications/progress'):
            return None                        # 通知：不回包
        if method == 'ping':
            return None if is_notification else _result(mid, {})
        if method == 'tools/list':
            return None if is_notification else _result(mid, {'tools': TOOL_LIST})
        if method == 'tools/call':
            res = handle_tools_call(msg.get('params') or {})
            return None if is_notification else _result(mid, res)
        log('unknown method: %r' % method)
        if is_notification:
            return None
        return _error(mid, -32601, 'Method not found: %s' % method)
    except Exception as e:                     # 单条请求异常 → JSON-RPC 内部错误，不退出
        log('handler crashed: %s' % _err(e))
        log(traceback.format_exc())
        if is_notification:
            return None
        return _error(mid, -32603, 'Internal error: %s' % _err(e))


def send(obj):
    """写一行完整 JSON 到 stdout（UTF-8，ensure_ascii=False，无反斜杠转义）。"""
    data = json.dumps(obj, ensure_ascii=False) + '\n'
    sys.stdout.buffer.write(data.encode('utf-8'))
    sys.stdout.buffer.flush()


def main():
    try:
        sys.stderr.reconfigure(encoding='utf-8', errors='replace')
    except Exception:
        pass
    # 库根必须有明确来源：拿不到就报错退出，绝不静默指向别人的机器路径（N9 判据②）
    if not AW:
        sys.stderr.write('[kbhub] ERR 没有拿到 KBHUB_AW：装载层 env 未设置。\n'
                         '[kbhub]     修法：在包目录跑一次 `python install.py`（它会写本机 AI-Workspace 根），\n'
                         '[kbhub]     或手工给 MCP 配置加 env: {KBHUB_AW: <你的 AI-Workspace>}。\n')
        sys.stderr.flush()
        return 2
    if not os.path.isdir(KB):
        sys.stderr.write('[kbhub] ERR KBHUB_AW 指向的目录里没有 协作库：%s\n' % AW)
        sys.stderr.flush()
        return 2
    log('kbhub 0.1.0 启动 pid=%d python=%s AW=%s' % (os.getpid(), sys.version.split()[0], AW))
    while True:
        try:
            raw = sys.stdin.buffer.readline()
        except KeyboardInterrupt:
            log('KeyboardInterrupt，退出')
            return 0
        except Exception as e:                 # 读 stdin 本身出问题，只能退
            log('读 stdin 失败：%s' % _err(e))
            return 1
        if not raw:                            # stdin EOF → 正常退出
            log('stdin EOF，正常退出')
            return 0
        line = raw.decode('utf-8', 'replace').strip()
        if not line:
            continue
        try:
            msg = json.loads(line)
        except Exception as e:
            send(_error(None, -32700, 'Parse error: %s' % _err(e)))
            continue
        try:
            resp = handle(msg)
        except Exception as e:                 # handle 理论上已兜底，再兜一层
            log('handle 外抛：%s' % _err(e))
            mid = msg.get('id') if isinstance(msg, dict) else None
            resp = None if mid is None else _error(mid, -32603, 'Internal error: %s' % _err(e))
        if resp is not None:
            try:
                send(resp)
            except Exception as e:             # stdout 断了（客户端走了）
                log('写 stdout 失败，退出：%s' % _err(e))
                return 0


if __name__ == '__main__':
    sys.exit(main())
