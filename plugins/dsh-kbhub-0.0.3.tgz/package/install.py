#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""kbhub 装载层的安装器：把 cordis.patch.yml 里的占位符与本机库根写进去。

本包的装载层里不写作者机器的绝对路径，装的时候要落两处本机值：

1. `args` 里的 `__KBHUB_SERVER__` → 本包目录下 kbhub_server.py 的绝对路径。
   为什么必须绝对：`@deepseek-ai/dsh-mcp-client` spawn 子进程时 cwd 是宿主进程的 cwd，
   不是包目录，`args` 写包相对路径在宿主里必然找不到。
2. `env.KBHUB_AW` → 本机 AI-Workspace 根（判断依据：目录下同时有 `协作库\\` 与 `工具\\`）。
   为什么也要写：kbhub_server.py 不再猜路径，拿不到 KBHUB_AW 就报错退出；
   所以装载层必须把本机值显式传下去，否则「MCP 起得来、工具全废」。

用法（在本目录执行）：
    python install.py                  # 写入（默认动作）
    python install.py --check          # 只看状态：rc 0=两处都就绪 / 1=有未就绪项
    python install.py --show           # 打印 args 与 env 两处现状
    python install.py --aw D:\\x\\AI-Workspace   # 手工指定库根（侦测不到时用）
    python install.py --python C:\\path\\python.exe
    python install.py --restore        # 换回占位符并删掉 env（打包前用，保证 tgz 干净）

设计口径：
- 只动 `args:` 下那一条服务脚本、可选的 `command:`、以及 env 里的 `KBHUB_AW`；其它字段一字不改。
- 库根侦测只看目录形状，不猜、不扫盘；侦测不到就明确 WARN 且不写 env（服务会报错，好过静默错路径）。
"""
from __future__ import print_function

import io
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
PATCH = os.path.join(HERE, "cordis.patch.yml")
SERVER = os.path.join(HERE, "kbhub_server.py")
PLACEHOLDER = "__KBHUB_SERVER__"
PY_PLACEHOLDER = "__PYTHON__"
ENV_KEY = "KBHUB_AW"


def read_patch():
    if not os.path.exists(PATCH):
        raise SystemExit("[ERR] 找不到 %s" % PATCH)
    with io.open(PATCH, encoding="utf-8") as fh:
        return fh.read()


def write_patch(text):
    with io.open(PATCH, "w", encoding="utf-8", newline="\n") as fh:
        fh.write(text)


def find_arg_line(lines):
    """返回服务脚本那一行的行号：args: 下面第一条「是占位符或以 kbhub_server.py 结尾」的 - 项。

    args 里可能还有解释器开关（如 `-X`、`utf8`），不能直接取第一条。
    """
    start = None
    for i, line in enumerate(lines):
        if line.strip().startswith("args:"):
            start = i
            break
    if start is None:
        raise SystemExit("[ERR] cordis.patch.yml 里没有 args:")
    candidates = []
    for i in range(start + 1, len(lines)):
        stripped = lines[i].strip()
        if not stripped:
            continue
        if not stripped.startswith("-"):
            break
        candidates.append(i)
    if not candidates:
        raise SystemExit("[ERR] args: 下面没有条目")
    for i in candidates:
        value = lines[i].split("-", 1)[1].strip()
        if value == PLACEHOLDER or value.replace("\\", "/").endswith("kbhub_server.py"):
            return i
    return candidates[-1]


def find_command_line(lines):
    for i, line in enumerate(lines):
        if line.strip().startswith("command:"):
            return i
    return None


def find_env(lines):
    """返回 (env 行号, KBHUB_AW 子行号或 None)；env 块按 10 空格子行识别。"""
    for i, line in enumerate(lines):
        if line.strip() == "env:":
            child = None
            for j in range(i + 1, len(lines)):
                stripped = lines[j].strip()
                if not stripped:
                    continue
                if not lines[j].startswith(" " * 10):
                    break
                if stripped.split(":", 1)[0].strip() == ENV_KEY:
                    child = j
            return i, child
    return None, None


def detect_aw(start):
    """从本包目录往上找 AI-Workspace 根：同时有 `协作库` 与 `工具` 两个目录。"""
    cur = os.path.abspath(start)
    for _ in range(8):
        if os.path.isdir(os.path.join(cur, "协作库")) and os.path.isdir(os.path.join(cur, "工具")):
            return cur
        parent = os.path.dirname(cur)
        if parent == cur:
            break
        cur = parent
    return None


def set_env(lines, aw):
    env_idx, child = find_env(lines)
    if child is not None:
        head = lines[child].split(":", 1)[0]
        lines[child] = "%s: %s" % (head.rstrip(), aw)
        return "cover"
    if env_idx is not None:
        lines.insert(env_idx + 1, " " * 10 + "%s: %s" % (ENV_KEY, aw))
        return "insert"
    for i, line in enumerate(lines):
        if line.strip().startswith("transport:"):
            lines[i + 1:i + 1] = ["        env:", " " * 10 + "%s: %s" % (ENV_KEY, aw)]
            return "insert-block"
    raise SystemExit("[ERR] 找不到 transport: 行，没法安放 env 块")


def drop_env(lines):
    env_idx, child = find_env(lines)
    if child is not None:
        del lines[child]
    env_idx, child = find_env(lines)
    if env_idx is not None and child is None:
        del lines[env_idx]


def state(lines):
    idx = find_arg_line(lines)
    value = lines[idx].split("-", 1)[1].strip()
    _, child = find_env(lines)
    aw = lines[child].split(":", 1)[1].strip() if child is not None else None
    server_ok = (value != PLACEHOLDER) and os.path.exists(value)
    aw_ok = bool(aw) and os.path.isdir(os.path.join(aw, "协作库"))
    tool_ok = bool(aw) and os.path.isdir(os.path.join(aw, "工具"))
    return idx, value, aw, server_ok, aw_ok, tool_ok


def main(argv):
    check = "--check" in argv
    show = "--show" in argv
    restore = "--restore" in argv
    py = None
    if "--python" in argv:
        pos = argv.index("--python")
        if pos + 1 >= len(argv):
            raise SystemExit("[ERR] --python 需要参数")
        py = argv[pos + 1]
    aw_arg = None
    if "--aw" in argv:
        pos = argv.index("--aw")
        if pos + 1 >= len(argv):
            raise SystemExit("[ERR] --aw 需要参数")
        aw_arg = os.path.abspath(argv[pos + 1])

    lines = read_patch().split("\n")
    idx, value, aw, server_ok, aw_ok, tool_ok = state(lines)

    if restore:
        lines[idx] = lines[idx].replace(value, PLACEHOLDER)
        drop_env(lines)
        write_patch("\n".join(lines))
        print("[ok] 已换回占位符 %s 并移除 env.%s（打包前状态）" % (PLACEHOLDER, ENV_KEY))
        return 0

    if show or check:
        print("args 行：%s" % lines[idx].strip())
        print("env.%s：%s" % (ENV_KEY, aw if aw else "（未设置）"))
        print("[state] server %s；库根 %s；工具目录 %s" % (
            "已就绪" if server_ok else ("仍是占位符" if value == PLACEHOLDER else "路径不存在：%s" % value),
            "已就绪" if aw_ok else ("未设置" if not aw else "目录不对：%s" % aw),
            "已就绪" if tool_ok else ("未设置" if not aw else "缺失：%s" % os.path.join(aw or "", "工具"))))
        if aw_ok and not tool_ok:
            print("[WARN] 库根下有 协作库\\ 但没有 工具\\：kbhub 的 kb_check 与写探针要用 工具/kb/kb_check.py，"
                  "装上去会「加载成功但工具静默不可用」。")
        if not os.path.exists(SERVER):
            print("[ERR] 同目录没有 kbhub_server.py：%s" % SERVER)
            return 1
        print("[server] %s" % SERVER)
        return 0 if (server_ok and aw_ok and tool_ok) else 1

    if not os.path.exists(SERVER):
        raise SystemExit("[ERR] 同目录没有 kbhub_server.py：%s" % SERVER)
    lines[idx] = lines[idx].replace(value, SERVER)
    print("[ok] 已写入 %s" % SERVER)
    ci = find_command_line(lines)
    if py:
        if ci is None:
            raise SystemExit("[ERR] cordis.patch.yml 里没有 command:")
        head = lines[ci].split(":", 1)[0]
        lines[ci] = "%s: %s" % (head, py)
        print("[ok] 解释器改为 %s" % py)
    elif ci is not None and lines[ci].split(":", 1)[1].strip() == PY_PLACEHOLDER:
        head = lines[ci].split(":", 1)[0]
        lines[ci] = "%s: python" % head
        print("[WARN] 没给 --python，解释器写成 `python`（要求它在 PATH 里）；不对就重跑一次 --python <路径>")

    aw = aw_arg or detect_aw(HERE)
    if aw and os.path.isdir(os.path.join(aw, "协作库")):
        how = set_env(lines, aw)
        print("[ok] env.%s = %s（%s）" % (ENV_KEY, aw, how))
    else:
        drop_env(lines)
        print("[WARN] 侦测不到 AI-Workspace 根（要同时有 协作库\\ 与 工具\\），没有写 env.%s。" % ENV_KEY)
        print("       这种状态下 kbhub_server.py 会直接报错退出；请用 --aw <你的 AI-Workspace> 重跑一次。")
    write_patch("\n".join(lines))
    print("重启宿主后生效；`python install.py --check` 可复核。")
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
