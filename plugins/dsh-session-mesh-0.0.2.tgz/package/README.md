# dsh-session-mesh（会话间投递）

开发线的院子。给「多个会话互相说话」提供通道：宿主侧 index.js（投递/限流/holds）、浏览器半段 client.js（SSE 连着、拿到就转给当前会话）、命令行 mesh.py（`status` / `send`）。

## 文件

| 文件 | 作用 |
|---|---|
| `index.js` | 宿主插件本体：投递、限流、holds、事件落盘 |
| `client.js` | 浏览器半段：连 base、收消息、转给会话 |
| `mesh.py` | 命令行：`status` 看现场、`send` 投递 |
| `cordis.patch.yml` | 安装与默认 config（回滚命令写在文件头） |
| `package.json` | `dsh-session-mesh`，注册 id 必须等于包名 |

## 现场文件

| 路径 | 内容 |
|---|---|
| `$DSH_HOME/mesh/mesh-base.txt` | 当前 base（宿主重启换端口时它跟着变，例：`http://127.0.0.1:57267`） |
| `$DSH_HOME/mesh/mesh-token.txt`（或 `DSH_MESH_TOKEN_FILE`） | 调用要带的 token |
| `$DSH_MESH_EVENTS`（默认 `~/.dsh-mesh/mesh-events.jsonl`） | 事件流：`{ts, kind, event, detail}`，`kind:"client"` + `event:"ready"` 就是浏览器半段连上了 |
| `$DSH_MESH_MACHINE/mesh-state.json`（默认 `~/.dsh-mesh/machine/`） | 状态：`schema` / `rate` / `holds` |
| `$DSH_MESH_MACHINE/deliveries.jsonl` | 投递账本 |

## 命令

```bash
python 工具\mesh\mesh.py status
python plugins/mesh.py send --from 我 --mode queue --to <会话 id> < 正文文件
```

- `--mode queue`：对方空闲就立刻送，忙就排队（默认）
- `--mode interrupt`：插进对方当前回合
- `--mode passive`：只放收件箱、不叫醒；超过升级时限自动升成唤醒
- 正文一律走 stdin（塞进双引号里会被 shell 吃掉反引号）

## 两个时限别混（口径）

| 名字 | 默认 | 含义 | 来源 |
|---|---|---|---|
| `holdMs` | **30 秒**（`cordis.patch.yml`） | **投递占用**：同一会话在这么久内算「正在投递」，`mesh.py status` 的 `dispatch holds` 行用它 | `index.js` 的 `DEFAULT_HOLD_MS` 常量——归一化（`:1164`）与投递（`:619`）**共用同一个**，源码里没有第二个默认值（O53 已收口） |
| `PASSIVE_UPGRADE_MS` | **10 分钟** | **passive 升级等待**：`passive` 投递超过这么久没被消费就升级成唤醒，`mesh.py status` 的 `passive holds` 行用它 | `index.js:49`，可用环境变量 `DSH_MESH_PASSIVE_UPGRADE_MS` 覆盖 |

一句话：**30 秒是「投递占用」，10 分钟是「passive 多久变成叫醒」**。

## 其余 config 键（`cordis.patch.yml`）

`logOnly`（默认 `false`，打开就只记意图不投递）、`ratePerHour`（默认 20）、`fallbackMs`（默认 60000）。

## client ready 怎么验

1. 直接观测：`python 工具\mesh\mesh.py status` 的 `clients：N`，N ≥ 1 表示有 GUI 页面连着（页面开合会变）。
2. 代理观测：`build\mesh-events.jsonl` 里最近一条 `{"kind":"client","event":"ready"}` 的时间。
3. 两者都要能复跑；页面没开时写「未直接观测，以事件流最近一条 ready 与 `--doctor` 四段代理」，不要让验收依赖「有人开着页面」。

## 生产观测（不是只在自检里过）

2026-11-03 00:43 的宿主日志（`<userData>/logs/crash-*-host.log`，桌面版把 renderer 与 host 控制台都写在这里）里：

- `[session-mesh-lite] target busy, falling back to direct queue: agent "session-…" already has active work` 出现 **13 次**，**消息照样投到** ⇒ 忙时降级（R1/R2）在真机生效。
- 同一份日志里 242 行有 **203 行**是 `http://127.0.0.1:18787/__bili/upstreams` 的 CORS 报错（那是 billion-context 的 zone 端口，不是本插件）——排查本插件问题时先把这类噪音滤掉。

## 坑

- **base 跟着宿主端口变**：宿主每次启动换端口，`mesh-base.txt` 会更新；用旧端口会 `http=000`（连不上），读 `mesh-base.txt` 永远是对的。
- **中文 passive 的落盘格式**：现在是 `text_b64`（M81 修的），旧运行实例仍会写裸 `text`，会让 `kb_check` 第 13 项红；重启后自愈。
- **注册 id 必须等于包名**：装/拆带 Web 半段的插件都要冷启动复验；界面打不开时唯一回滚＝删 `$DSH_HOME/profiles/<profile>/package.json` 里 bundles 那一行后重开。

## O63：账本状态语义与补投（2026-11-04 修）

**病**：成功投递曾记 `status: 'queued'`，而启动补投 `retryPending()` 又把 `queued` 当「待重投」——
每次插件加载都重投一批已投到的信，重投成功再写一条 `queued` ⇒ 账本自己喂自己。
维护线实测：20 分钟内同一封信被叫醒 20 次，账本 `queued` 涨到 190 行。

**现在的状态表**（`deliveries.jsonl` 每行 `status`）：

| status | 谁写的 | 补投会不会挑它 |
|---|---|---|
| `pending` | 投递前先落（意图） | **会**（崩溃/异常留下的唯一入口） |
| `failed` | 投递抛错时 | **会** |
| `delivered` | 投递成功 | 不会（出现过就永不再投） |
| `queued` | 2026-11-04 之前的历史成功行 | 不会（按已投到算） |
| `refused` / `rate_limited` / `target_rate_limited` / `log_only` | 拒收与闸门 | 不会（已裁定，重投必再被同一规则拒回） |

**补投的三道保险**（`pickRetryCandidates()`，纯函数，可单测）：
1. 只认「末行是 `pending` 或 `failed`」且全账本没有一条「到过」的行；
2. 同一条 `msg_id` 24 小时内至多重投 1 次（`retry_attempt` 行记账）；
3. 每次加载最多 5 条，且只取 24 小时内、带正文的。

**反例集**：`node 工具/mesh/test-retry-pending.mjs`（12 项，含「同一封信 5 条 queued」这条旧风暴形状 → 0 候选）。`pickRetryCandidates` 是 `index.js` 的具名导出（cordis 认的是 `apply`，多一个纯函数导出不影响加载）。
真账本复核：368 行 → 补投候选 **0**。

**生效**：改的是宿主半段（`index.js`），要重启宿主才加载；`build\mesh-client-selfcheck.mjs` 里那几条源码断言同步改了。

## O46②：补投节奏（2026-11-04 修）

**改之前**：插件加载后 5 秒跑一轮 `retryPending`，单发一次就结束。两个毛病：5 秒是拍的，宿主刚起来时对端会话常没就绪，那一轮必然失败、之后再也不投；同一封信反复失败也没有认输的地方，会一直躺在 `pending`/`failed` 里每天被捞一次。

**改之后**：

| 项 | 值 | 说明 |
|---|---|---|
| 退避序列 | 5s → 10s → 20s → 40s → 80s → 160s → 320s → 600s（封顶） | `retryBackoffMs(round)`，`RETRY_BACKOFF_BASE_MS=5000` / `RETRY_BACKOFF_MAX_MS=600000` |
| 轮次数 | 最多 `RETRY_MAX_ROUNDS = 8` 轮 | 跑满收手，不永久挂着；timer 都 `unref()`，销毁时 `clearTimeout` |
| 认输（升级） | 同一 `msg_id` 攒到 `RETRY_ESCALATE_AFTER = 3` 次尝试、且一次都没到过 | 写 `status: 'escalated'` 行（带 `attempts`）+ `console.warn`，此后不再投 |

**为什么升级判定独立于候选挑选**：`pickRetryCandidates` 受 24 小时冷却约束，若把「认输」也塞进去，一封信要攒到第 3 次得等三天才看得见。所以拆成 `pickEscalations(rows)`：只看尝试次数与「有没有到过」，每轮都扫。

**O63 的 12 条判据一条没动**：`pickRetryCandidates` 的语义不变（T1–T12 原样跑），新的一组 T13–T20 只测退避、计数、升级边界。合起来 `node 工具\mesh\test-retry-pending.mjs` → **20/20**。

## O38 R5：配置 schema（2026-11-04 修）

**病**：插件没有 `export const Config` 时，宿主不校验配置。`cordis.patch.yml` 里把 `holdMs` 写成 `holdMS`、`ratePerHour` 写成 `rateperhour`，整片键会静默落到默认值——线上看着「配置生效了」，其实一个字都没读到。

**改**：

```js
export const Config = schema && schema.object({
  logOnly: schema.boolean().default(false),
  holdMs: schema.number().step(1).min(1000).max(600000).default(DEFAULT_HOLD_MS),
  ratePerHour: schema.number().step(1).min(1).max(1000).default(20),
  fallbackMs: schema.number().step(1).min(0).max(600000).default(60000),
});
```

两层防护，缺一不可：

| 层 | 抓什么 | 证据 |
|---|---|---|
| schema 校验 | 类型错、超范围 | `Config({holdMs:'abc'})` → `$.holdMs expected number but got abc`；`Config({holdMs:999999})` → `... <= 600000 but got 999999` |
| `apply()` 里未知键点名 | **拼错的键名**（schemastery 的 object 不剥未知键，`holdMS:5000` 会原样留下） | `[session-mesh-lite] 配置里有不认识的键：holdMS（认识的只有 logOnly, holdMs, ratePerHour, fallbackMs）` |

**一个坑（会炸加载的写法）**：不要写 `import z from '@deepseek-ai/schemastery'`。本插件的真实路径是 `工具\mesh`（profile 里是链接），从那里向上没有 `node_modules`，静态 import 会让插件在宿主里直接加载失败。改成 `createRequire(<DSH_HOME>/profiles/<profile>/package.json)` 解析，拿不到就退化为「没有 schema」（等于改之前的行为）并 `console.warn` 说清楚。

**别在本地拿假 ctx 调 `apply()`**（2026-11-04 事故）：`apply()` 会写 `$DSH_HOME/mesh/mesh-token.txt` 并轮换 token，运行中的插件只认内存里那份 ⇒ 一次本地测试就把线上 token 覆盖成对不上的值，`mesh.py` 与 watcher 直投全部 401，直到下一次宿主重启。现在有三个口子：`DSH_MESH_TOKEN_FILE=<别的路径>`、`DSH_MESH_NO_TOKEN_WRITE=1`（测试用这个）、默认行为不变。

## O38 R6：source kind 不在宿主的类型枚举里（接受，写清后果）

**现象**：插件写进会话日志的来源是 `"source":{"kind":"plugin:session-mesh-lite","form":"notice",…}`，而宿主的 `MessageSourceMap` 联合类型里没有这个键。

**为什么不改**：那张 map 是类型层声明，写在打包好的 `app.asar` 里，插件侧改不到；运行期**是能写的**（实测会话日志正常落盘、GUI 正常显示）。而 `plugin:<name>` 恰好是 session-format v4 在落盘路径上唯一认的 producer-owned 形态 —— `{kind:"plugin", plugin}` 和裸 custom kind 会被编码器直接拒，换掉等于现在就不能写。

**后果（写清，不掩盖）**：若某个宿主版本开始在落盘路径上校验那张 map，我们的行会被拒；症状不是报错，而是「投递返回 accepted，但会话日志里没有这条消息」。排查顺序：① 打开刚投那条消息所在会话的日志 ② 找 `"kind":"plugin:` ③ 找不到就是被拒，退到 `form: notice` + 宿主既有 kind，或等上游加枚举。

**钉住它的东西**：`build\mesh-client-selfcheck.mjs` 三条断言 —— kind 字面必须是 `plugin:session-mesh-lite`、不许出现 `kind: 'plugin', plugin:`、注释里必须保留 MessageSourceMap 的后果说明。

## O38 R3：句柄（AgentHandle）不许漏

`ctx.agents.resume()` 返回的 `AgentHandleLike { agent, dispose(): Promise<void> }`（见 `dsh-proactive/lib/wake.d.ts:164-168`）必须在拿到手之后有人负责放回去。原来这条责任只在 `runtime.holds` 的租约里，四处漏：

| 位置 | 原来的写法 | 后果 | 现在 |
|---|---|---|---|
| passive 升级 timer | `const { agent } = await acquireAgent(...)` | **真漏**：冷恢复拿到的 handle 引用当场丢失，会话被永久拉起，teardown 也看不见它（只遍历 `runtime.holds`） | 保留 `acquired`，`finally` 里 `await dispose()` 并记一行 `released` |
| 启动补扫 `restorePassiveHolds` | 同上，每项调一次 | 开机瞬时对 N 个冷会话各 resume 一次、0 次 dispose | 同上，随 schedulePassiveUpgrade 一起修好 |
| 投递失败（`!accepted`） | handle 已进 `runtime.holds`，等 30 秒 sweep 收 | 不是漏（有界 ≤60s），但一条没被接收的消息把会话装成 live 最长 60 秒 | 立即释放并记账，不再白占租约 |
| teardown 窗口 | 先 `clearInterval(sweep)`，后 `holds.clear()` | **竞态真漏**：这段窗口里落地的在飞投递把 handle 写进再也不会被扫的 Map，永久漏且不报错 | 开头立 `runtime.disposed = true`，`deliver` 拿到 handle 后复查，命中就以 `reason: 'disposed'` 拒绝并当场 dispose |
| `void handle?.dispose?.()`（三处） | `void` 掉 Promise | rejection 逃出 try/catch（unhandled rejection）；且无论成败都写 `released`——**假释放账** | 统一 `await` 或 `.then(ok, fail)`，只有 resolve 才写 `released`，失败写 `release_failed` |
| `resolveAgent` 分支 | `handle: resolved?.handle ?? null` | 若它复活冷会话却没带 handle，与「宿主已持有的 live」无法区分 → 同型静默拉起（**无法证伪**） | 不改调用顺序（改了风险更大），但补一行 `lease_unknown` 账：谁在没租约的情况下把会话拉起来 |

另补一条 `stale_lease`：新投递走 live（handle=null）而 `holds` 里还压着旧 handle 时记账——至少「谁握着过期租约」查得到。

**判据（结构层，`build\mesh-client-selfcheck.mjs` 四条断言）**：passive 路径必须 `acquired = await acquireAgent(...)`（禁止 `const { agent } = ...`）、finally 里 dispose 的记账串在位、`runtime.disposed` 立旗 + `deliver` 复查、全文不许再出现 `void ...dispose?.()`。

**未验证（如实记）**：宿主侧 `dispose()` 是否真把会话放回冷态、`resume` 撞 live 时的确切报错，profile 里既没有 .d.ts 也没有 JS 可读；「不再漏」只有结构证据，没有运行期计数。

## O38 R4 / R7：冷恢复的模型选择，与 `resolveAgent` 的 `{error}`

两条都是「不报错但悄悄做错事」那一类，2026-11-04 一起修。

**R4：`reasoningEffort` 被丢掉。** `agentDefaultModel.currentSelection()` 回的是宿主 `ModelSelection`
＝`{ provider, model, reasoningEffort? }`，`agents.resume({ agentOptions })` 收的 `AgentOptions` 也有
`reasoningEffort?: ReasoningEffortId`。原来只拷了前两个字段 ⇒ 用户选的思考强度在「插件叫醒冷会话」这条路上
被静默丢弃：会话照样起来，只是用默认强度跑，日志里一个字都不会有。
现在 `agentOptions()` 第三段照直传（只在是**非空字符串**时才传，避免把 `undefined`/`''` 塞进 AgentOptions）。

**R7：`resolveAgent()` 的 `{error}` 被当成 agent。** `sessionController.resolveAgent()` 的类型是
`{ agent } | { error: { message? } }`；原来写 `const agent = resolved?.agent ?? resolved`，出错时把 `{ error }` 这层壳
当成 agent 往下判——虽然随后的 `typeof agent.runMaintenance === 'function'` 让它落不进分支，但后果有两个：
① **白跑一次 `agents.resume()`**；② `error.message` 被整条丢掉，日志只剩一句「resume 失败」。
现在显式认这个形态：写一行 `status: 'resolve_error'` 审计（带 `error.message`）+ 一句 warning，然后照旧走 resume 兜底
（`resolveAgent` 的 error 不必然意味着 resume 也会失败，所以不砍兜底，只是不再假装它是个 agent）。

**反例集**：`node 工具\mesh\test-agent-options.mjs` → **7/7**（R4 三条：字段全传／缺字段不硬塞／空串不传；
R7 三条：不返回假 agent／兜底仍走／审计行带 message；外加一条正常形态不白跑 resume）。

它是怎么测私有函数的：把 `index.js` 复制到 `build\staging\__r47check`，在副本末尾追加
`export { agentOptions, acquireAgent };` 再 import——测的是同一份源码，真文件不改；`DSH_MESH_MACHINE` 指到临时目录
（journal 不污染协作库账本）、`DSH_MESH_NO_TOKEN_WRITE=1`（绝不碰 token）。

## O38 R8：本地兜底的工具参数校验，与宿主同口径

宿主 `defineTool(options)` 在调 `execute` 之前先自己校验一遍参数：

```
const parameters = parameterSchemaSpecToJsonSchema(options.parameters);
const validate = (args) => validateJsonSchemaValue(parameters, args, "");
… if (violations.length > 0) throw new ToolArgsError(violations);
```

`ToolArgsError` 的 `message` 是 `invalid arguments: <violations.join("; ")>`、`code` 是 `INVALID_ARGS`。
我们的本地兜底 `localDefineTool()` 原来**不校验**，直接把 `args` 交给 `execute` —— 于是同一个工具在
「宿主提供了 `defineTool`」与「只有本地兜底」两种环境里，对同一份烂参数给出两种错误面：一边是
`invalid arguments: missing required property "text"`，另一边是 `execute` 里自己判出的一句话，或者干脆把
`undefined` 往下传。

**补的是本地这条路径（宿主那条本来就验，不去重复动它）**：`localDefineTool()` 的 `execute` 开头先跑
`validateToolArgs(parameters, args)`，有违反项就抛 `ToolArgsError`（同名、同 `code`、同样 `"; "` 拼接、
同样的根/属性路径口径）。

**刻意没做的一件事：不拒绝多余字段。** 宿主的 `parameterSchemaSpecToJsonSchema()` 生成的对象 schema
**没有** `additionalProperties: false`，所以模型多给的键是允许的；本地若擅自拒绝，就等于凭空造出第三种行为
（「同一份参数，在两种环境下对错不同」正是这条要消灭的东西）。校验器支持 `additionalProperties: false`，
但只在 schema 真的写了这个关键字时才生效。

对照表（`violations` 原文，逐字对齐宿主）：

| 情形 | 文案 |
| --- | --- |
| 根不是对象 | `"arguments" must be an object` |
| 缺必填 / 值为 `undefined` | `missing required property "text"`（嵌套时 `"nested.depth"`） |
| 类型不符 | `"to" must be a string` / `must be a number` / `must be a finite JSON number` / `must be an integer` / `must be a boolean` / `must be an object` / `must be an array` / `must be null` |
| 枚举不命中 | `"mode" must be one of ["queue","interrupt"]` |
| 多余字段（仅显式 `additionalProperties: false`） | `"b" is not a declared property (additionalProperties: false)` |

**顺序也照宿主**：先子属性违规、再 tail（缺必填、多余字段）——因为宿主的 `required` /
`additionalProperties` 判定都在 `tailViolations` 里，children 走完才 append。所以

```
{ to: 1, mode: 'shout' }
→ invalid arguments: "to" must be a string; "mode" must be one of ["queue","interrupt"]; missing required property "text"
```

**反例集**：`node 工具\mesh\test-tool-args.mjs` → **14/14**（缺必填／类型不符／多余字段放行／枚举／嵌套缺参／
数组元素类型／根非对象／`undefined` 算缺必填／integer 与 number 区分／合格参数原样透传／多错并列顺序／
`additionalProperties:false` 才拒／没该关键字放行／合格调用只跑一次 `execute`）。
测法与 R4/R7 同一套：副本追加 `export { localDefineTool, validateToolArgs, ToolArgsError };`，真文件不改。

**未验证**：真机侧那半（宿主是否会因为参数不合格在实际消息链路上给出同样的报错面）留到下次窗口用一条
真实投递顺带看；本地这层只有结构与 14 条反例的证据。

## P0 教训（2026-11-05）：插件配置 schema 不许是 null

宿主 `settings/describe` 会遍历每个插件的 Config schema 并做 `'toJSON' in schema`；
`schema` 为 **null** 时抛 `gateway/internal: Cannot use 'in' operator to search for 'toJSON' in null`，
欢迎窗口第一个 RPC 失败 ⇒ **整个桌面窗口打不开**（web 服务本身正常，所以「禁用插件能进」）。

本插件曾经的写法 `export const Config = schema && schema.object({…})` 正好会在
「解析不到 @deepseek-ai/schemastery」时导出 `null`。现在的写法：

- `const ConfigSchema = schema && schema.object({…})`；`export const Config = ConfigSchema || undefined;`
- 拿不到 schema 就不导出（等于没有 Config），未知键告警改用固定清单 `CONFIG_KEYS`；
- `build\mesh-client-selfcheck.mjs` 有两条断言守这件事：`export const Config = ConfigSchema || undefined;` 必须在、
  `export const Config = schema &&` 不许出现。

同理：任何依赖「运行时才拿到的库」来构造 Config 的插件都有这个坑，构造失败必须退化成「没有 Config」，
不能退化成「null Config」。
