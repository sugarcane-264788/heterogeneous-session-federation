/**
 * dsh-session-mesh — Host half.
 *
 * Purpose
 * -------
 * Give any Session a supported way to hand a message to another Session, and
 * make sure the browser learns about it the moment it happens. Two problems it
 * solves at once:
 *
 *   1. Delivery. Three native modes, all implemented by the Host's Agent:
 *        queue     -> agent.followup(message)  (inbox, wake the driver)
 *        interrupt -> agent.steer(message)     (inject into the current turn)
 *        passive   -> agent.inject(message)    (inbox only, never wakes)
 *      A passive message that nobody consumed in 10 minutes is upgraded to a
 *      `followup`, so "don't interrupt" never turns into "silently lost".
 *
 *   2. Visibility. A message injected by a plugin never produces
 *      `api-session/activity` (the Host only forwards user-sourced messages),
 *      so the Client list can stay stale. This plugin therefore owns its own
 *      notification line: the Host half emits an SSE frame on every accepted
 *      delivery, and the Web half (client.js) calls `ctx.sessions.refresh()`.
 *
 * Safety
 * ------
 * This code runs inside the Host process, outside the workspace sandbox. So:
 *   - no path parameter anywhere, two fixed directories only;
 *   - archived / bridge / subagent targets are refused before any side effect;
 *   - every failure becomes a JSON result, never a throw into the Host;
 *   - `logOnly: true` records the intent and delivers nothing.
 */
import { createHash, randomUUID } from 'node:crypto';
import { appendFileSync, existsSync, mkdirSync, readFileSync, readdirSync, renameSync, statSync, writeFileSync } from 'node:fs';
import { homedir } from 'node:os';
import { createRequire } from 'node:module';
import { dirname, join } from 'node:path';

export const name = 'session-mesh-lite';
export const inject = ['agents', 'tools'];


const PLUGIN = '[session-mesh-lite]';
const TOOL_PREFIX = 'mesh';
/**
 * Session-format v4 admits only producer-owned source kinds on the disk write
 * path, so this must stay `plugin:<name>` (`{kind:"plugin", plugin}` and bare
 * custom kinds are rejected when the row is encoded).
 */
const SOURCE_KIND = 'plugin:session-mesh-lite';

/**
 * O38 R6（接受，不修代码）：宿主的 `MessageSourceMap` 里没有这个 kind——它是
 * 类型层的联合类型声明，写在打包好的 app.asar 里，插件侧改不到；运行期是能写的
 * （实测会话日志里 `"source":{"kind":"plugin:dsh-session-mesh","form":"notice",…}`
 * 正常落盘、GUI 也认）。
 *
 * 后果写清：如果将来某个宿主版本开始**在落盘路径上校验**那张 map，我们的行会被拒；
 * 症状不是报错，而是「投递返回 accepted，但会话日志里没有这条消息」。真出现时按这个
 * 顺序查：① 读一条刚投的消息所在会话日志 ② 看有没有 `plugin:` 开头的 kind
 * ③ 没有就是被拒了，改用 `form: notice` + 宿主既有 kind（或等上游加枚举）。
 *
 * 为什么不改成「宿主已有的 kind」：`plugin:<name>` 是 session-format v4 在落盘路径上
 * 认的唯一「producer-owned」形态（`{kind:"plugin", plugin}` 与裸 custom kind 会被编码器
 * 拒），换掉等于现在就不能写。
 */
const NOTICE_FORM = 'notice';
const MODES = new Set(['queue', 'interrupt', 'passive']);
const PASSIVE_UPGRADE_MS = Number(process.env.DSH_MESH_PASSIVE_UPGRADE_MS ?? 10 * 60 * 1000);
const HOLD_SWEEP_MS = 30 * 1000;
// O53：holdMs 只有一个默认值（投递占用 30 秒）。归一化（:1164）与投递（:619）共用
// 这一个常量，别再在别处写第二个字面默认值——之前投递处那条「10 分钟」兜底是不可达的
// 死兜底（归一化已保证有限数），却让人以为 holdMs 可能是 10 分钟。
const DEFAULT_HOLD_MS = 30 * 1000;
// O39 兜底：宿主把会话的 agent 惰性创建，插件 load 时 roots() 是空的，而 agent/created
// 事件受 scope 过滤不一定到此。每 5 秒便宜地扫一遍 roots，把没注册过的补上（WeakSet 去重）。
const TOOL_SCAN_MS = 5 * 1000;
const JOURNAL_MAX_SCAN = 4000;

/** Fixed locations (no path parameter is ever accepted from a caller).
 *
 * 本包是**通用发布形态**，所以不给任何作者机器的绝对路径：
 *   - 想把这套机制的账本（投递账本／状态／事件流）落在你自己的协作库里，就把
 *     `DSH_MESH_MACHINE` 指到 `<工作区>/协作库/40-协作/_machine`；
 *   - 不设就落在 `~/.dsh-mesh/machine`（个人目录，不污染工作区）。
 */
const DEFAULT_MESH_HOME = join(homedir(), '.dsh-mesh');
const MACHINE_DIR = process.env.DSH_MESH_MACHINE
    || join(DEFAULT_MESH_HOME, 'machine');
const EVENTS_FILE = process.env.DSH_MESH_EVENTS
    || join(DEFAULT_MESH_HOME, 'mesh-events.jsonl');
const JOURNAL_FILE = join(MACHINE_DIR, 'deliveries.jsonl');
const STATE_FILE = join(MACHINE_DIR, 'mesh-state.json');
/**
 * Token 不随协作库备份走（2026-11-01 主对话评审第 3 条）：默认放 DSH 自己的目录，
 * `_machine\mesh-token.txt` 只作为旧版读取兜底，不再新写。可用 DSH_MESH_TOKEN_FILE 覆盖。
 */
const DSH_HOME_DIR = process.env.DSH_HOME || '';
/*
 * O45-⑨：`DSH_HOME` 未设置时，旧代码把 token 落回协作库的 `_machine/` —— 那里会随库备份走，
 * 等于把令牌塞进备份（2026-11-01 评审第 3 条的原意正好被这样绕回去）。
 * 现在回落目标是用户目录下的 `.dsh-mesh`，仍然不在库里，并且打一条 warn 说清楚原因。
 */
const FALLBACK_TOKEN_DIR = join(homedir(), '.dsh-mesh');
if (DSH_HOME_DIR === '' && process.env.DSH_MESH_TOKEN_FILE === undefined) {
    console.warn(`${PLUGIN} DSH_HOME 未设置；token 落在 ${join(FALLBACK_TOKEN_DIR, 'mesh-token.txt')}（个人目录，不在共享库里）`);
}
const TOKEN_FILE = process.env.DSH_MESH_TOKEN_FILE
    || (DSH_HOME_DIR === '' ? join(FALLBACK_TOKEN_DIR, 'mesh-token.txt') : join(DSH_HOME_DIR, 'mesh', 'mesh-token.txt'));
const LEGACY_TOKEN_FILE = join(MACHINE_DIR, 'mesh-token.txt');

/**
 * O38 R5：没有 `Config` 时，`cordis.patch.yml` 里的键拼错（`holdMS`、`rateperhour`）
 * 会整片静默落到默认值，线上看起来「配置生效了」，其实一个字都没读到。
 *
 * 依赖解析这里不走静态 `import`：插件被 link 到源码目录时（profile 里是链接）
 * （profile 里是链接），从那里向上找不到 `@deepseek-ai/schemastery`，静态 import 会让
 * 插件在宿主里加载失败。改成从 DSH profile 的 package.json 起解析，拿不到就退化为
 * 「没有 schema」（等于改之前的行为），并在日志里说清楚。
 */
function loadSchemastery() {
    const profileDir = join(DSH_HOME_DIR, 'profiles', process.env.DSH_PROFILE || 'desktop');
    const anchors = [
        join(profileDir, 'package.json'),
        // 从 profile 的 node_modules 里起解析：package.json 在某些场景下不是解析起点
        join(profileDir, 'node_modules', '__anchor.js'),
        join(DSH_HOME_DIR, 'package.json'),
    ];
    for (const anchor of anchors) {
        try {
            const requireFrom = createRequire(anchor);
            const mod = requireFrom('@deepseek-ai/schemastery');
            const zz = mod && mod.default ? mod.default : mod;
            if (zz && typeof zz.object === 'function') return zz;
        } catch (error) {
            // 继续试下一个锚点；全失败时下面的 warn 会说话
        }
    }
    console.warn(`${PLUGIN} 没能从 DSH profile 解析 @deepseek-ai/schemastery，Config 不导出（拼错的键只能靠日志发现）`);
    return null;
}

const schema = loadSchemastery();

/** 这四个键是 apply() 认的全部键；schema 拿不到时 apply() 用它点名拼错的键。 */
const CONFIG_KEYS = ['logOnly', 'holdMs', 'ratePerHour', 'fallbackMs'];

/** 与 `cordis.patch.yml` 的键一一对应；默认值与 `apply()` 里的一致。 */
const ConfigSchema = schema && schema.object({
    logOnly: schema.boolean().default(false).description('true 时只记账不投递'),
    holdMs: schema.number().step(1).min(1000).max(10 * 60 * 1000).default(DEFAULT_HOLD_MS).description('投递占用（hold）时长，默认 30 秒'),
    ratePerHour: schema.number().step(1).min(1).max(1000).default(20).description('同一发送方每小时投递上限；urgent: true 绕过并留审计行'),
    fallbackMs: schema.number().step(1).min(0).max(10 * 60 * 1000).default(60000).description('忙时降级（interrupt→queue）的等待上限'),
});

/**
 * 拿不到 schemastery 时**不能导出 `null`**：宿主 `settings/describe` 会遍历配置表，
 * 对每条 schema 做 `'toJSON' in schema`，遇到 null 就抛
 * `gateway/internal: Cannot use 'in' operator to search for 'toJSON' in null`，
 * 后果是整个桌面窗口的欢迎 RPC 失败 ⇒ app 打不开（2026-11-05 的事故就是这么来的）。
 * 没有 schema 时导出 undefined（= 等于没有 Config），并在 apply() 里用 CONFIG_KEYS 兜底。
 */
export const Config = ConfigSchema || undefined;

/** 撞墙也要留账（评审第 2 条）：拒收不是隐形事件。 */
const TARGET_RATE_LIMIT = 60;   // 同一目标 60 条/小时，跨所有发送方（评审第 5 条）
const URGENT_DAILY_LIMIT = 5;   // urgent 对同一目标 5 条/日（评审第 6 条）

const FORBIDDEN_CALLER = new Set(['main', 'email']);

function describeError(error) {
    if (error === undefined || error === null) return undefined;
    const message = typeof error?.message === 'string' ? error.message : String(error);
    const code = typeof error?.code === 'string' ? error.code : undefined;
    return code === undefined ? message : `${code}: ${message}`;
}

/* ------------------------------------------------------------------ *
 * defineTool: prefer the Host copy, fall back to a local equivalent.
 * ------------------------------------------------------------------ */
let defineTool = null;
let defineToolOrigin = 'local';
/**
 * `createUserMessage` comes from `@deepseek-ai/dsh-llm`. The Host copy is only
 * reachable from inside the Host module graph, so it is imported best-effort and
 * the plain-object shape below is the fallback (verified against how
 * `dsh-proactive` builds its wake message: same fields, producer-owned kind).
 */
let createUserMessage = null;
let messageOrigin = 'local';

function propertyMapToJsonSchema(spec) {
    const properties = {};
    const required = [];
    for (const [key, raw] of Object.entries(spec ?? {})) {
        const { required: isRequired, ...rest } = raw ?? {};
        if (isRequired === true) required.push(key);
        properties[key] = schemaNode(rest);
    }
    const schema = { type: 'object', properties };
    if (required.length > 0) schema.required = required;
    return schema;
}

function schemaNode(spec) {
    const node = { type: typeof spec?.type === 'string' ? spec.type : 'string' };
    if (typeof spec?.description === 'string') node.description = spec.description;
    if (Array.isArray(spec?.enum)) node.enum = [...spec.enum];
    if (spec?.type === 'object') {
        const nested = propertyMapToJsonSchema(spec.properties);
        node.properties = nested.properties;
        if (nested.required !== undefined) node.required = nested.required;
    }
    if (spec?.type === 'array' && spec.items !== undefined) node.items = schemaNode(spec.items);
    return node;
}

/* ------------------------------------------------------------------ *
 * O38 R8：本地兜底的参数校验要与宿主同口径
 * ------------------------------------------------------------------ */
/*
 * 宿主 `defineTool(options)` 会在调 `execute` 之前先跑
 * `validateJsonSchemaValue(parameters, args, "")`，不合格就 `throw new ToolArgsError(violations)`；
 * 那个错误的 `message` 是 `invalid arguments: <violations.join("; ")>`、`code` 是 `INVALID_ARGS`。
 * 我们的本地兜底 `localDefineTool` 原来直接把 args 交给 execute —— 于是同一个工具，
 * 在「宿主提供 defineTool」与「只有本地兜底」两种环境下，对同一份烂参数给出两种错误面
 * （一边是 `invalid arguments: missing required property "text"`，一边是 execute 里自己判的
 * 「缺 text」或者干脆 undefined 传下去）。这里把宿主的校验口径搬过来，只补本地这条路径。
 *
 * 刻意没做的：**不拒绝多余字段**。宿主的 `parameterSchemaSpecToJsonSchema()` 生成的对象 schema
 * 没有 `additionalProperties: false`，所以模型多给的键是允许的；本地若擅自拒绝，就等于凭空造出第三种行为。
 */
class ToolArgsError extends Error {
    constructor(violations) {
        super(`invalid arguments: ${violations.join('; ')}`);
        this.name = 'ToolArgsError';
        this.code = 'INVALID_ARGS';
        this.violations = violations;
    }
}

function propertyPath(path, key) {
    return path === '' ? key : `${path}.${key}`;
}

function isPlainObjectLike(value) {
    return value !== null && typeof value === 'object' && !Array.isArray(value);
}

/** 按宿主那套消息文案，返回违反项（空数组＝合格）。 */
function validateToolArgs(schema, value, path = '', out = []) {
    const label = path === '' ? 'arguments' : path;
    const type = typeof schema?.type === 'string' ? schema.type : undefined;
    if (type === 'object') {
        if (!isPlainObjectLike(value)) {
            out.push(`"${label}" must be an object`);
            return out;
        }
        const properties = schema?.properties && typeof schema.properties === 'object' ? schema.properties : {};
        const required = Array.isArray(schema?.required) ? schema.required : [];
        // 顺序照宿主 checkValue：先逐属性递归（子节点违规），再拼 tail（缺必填、多余字段）。
        // 宿主的 required / additionalProperties 判定都在 tailViolations 里，children 走完才 append。
        for (const [key, child] of Object.entries(properties)) {
            if (Object.hasOwn(value, key) && value[key] !== undefined) {
                validateToolArgs(child, value[key], propertyPath(path, key), out);
            }
        }
        for (const key of required) {
            if (!Object.hasOwn(value, key) || value[key] === undefined) {
                out.push(`missing required property "${propertyPath(path, key)}"`);
            }
        }
        if (schema?.additionalProperties === false) {
            for (const key of Object.keys(value)) {
                if (!Object.hasOwn(properties, key)) {
                    out.push(`"${propertyPath(path, key)}" is not a declared property (additionalProperties: false)`);
                }
            }
        }
        return out;
    }
    if (value === undefined) return out;
    if (type === 'array') {
        if (!Array.isArray(value)) {
            out.push(`"${label}" must be an array`);
            return out;
        }
        const items = schema?.items;
        if (items !== undefined) {
            value.forEach((item, index) => validateToolArgs(items, item, `${path}[${index}]`, out));
        }
        return out;
    }
    const declared = Array.isArray(schema?.enum) ? schema.enum : undefined;
    if (declared !== undefined && !declared.some((allowed) => allowed === value)) {
        out.push(`"${label}" must be one of ${JSON.stringify(declared)}`);
        return out;
    }
    if (type === 'string' && typeof value !== 'string') out.push(`"${label}" must be a string`);
    else if (type === 'boolean' && typeof value !== 'boolean') out.push(`"${label}" must be a boolean`);
    else if (type === 'number') {
        if (typeof value !== 'number' || !Number.isFinite(value)) out.push(`"${label}" must be a finite JSON number`);
    } else if (type === 'integer') {
        if (typeof value !== 'number' || !Number.isFinite(value) || !Number.isInteger(value)) out.push(`"${label}" must be an integer`);
    } else if (type === 'null' && value !== null) out.push(`"${label}" must be null`);
    return out;
}

function localDefineTool(options) {
    const parameters = propertyMapToJsonSchema(options.parameters);
    const outputSchema = structuredClone(options.output?.schema ?? {});
    return {
        name: options.name,
        description: options.description,
        parameters,
        output: { schema: outputSchema, render: (args, value) => options.output.render(args, value) },
        async execute(args, exec) {
            // O38 R8：与宿主 defineTool 同口径的前置校验（宿主那条路径自己会验，本地这条原来不验）
            const violations = validateToolArgs(parameters, args);
            if (violations.length > 0) throw new ToolArgsError(violations);
            return options.execute(args, exec);
        },
    };
}

function makeTool(options) {
    return defineTool === null ? localDefineTool(options) : defineTool(options);
}

/* ------------------------------------------------------------------ *
 * Small state helpers
 * ------------------------------------------------------------------ */
function ensureDirs() {
    for (const dir of [MACHINE_DIR]) {
        try {
            if (!existsSync(dir)) mkdirSync(dir, { recursive: true });
        } catch {
            /* read-only deployments: journal appends will just fail and report */
        }
    }
}

/**
 * O45-A：state 里的 rate/holds 可能缺失或被写成非对象（旧文件、外部编辑、崩溃残片）。
 * 取用点若不兜底，`state.rate[key]` 会抛 TypeError，而异常会落进没有审计的分支——
 * 表现是「发送恒失败、账本上看不出来」。所以统一在入口把这两个桶归一。
 */
function normaliseState(state) {
    const out = state !== null && typeof state === 'object' ? state : {};
    if (out.schema === undefined || out.schema === null) out.schema = 1;
    if (out.rate === null || typeof out.rate !== 'object' || Array.isArray(out.rate)) out.rate = {};
    if (out.holds === null || typeof out.holds !== 'object' || Array.isArray(out.holds)) out.holds = {};
    return out;
}

function loadState() {
    return normaliseState(readJson(STATE_FILE, { schema: 1, rate: {}, holds: {} }));
}

function readJson(file, fallback) {
    try {
        if (!existsSync(file)) return fallback;
        return JSON.parse(readFileSync(file, 'utf8'));
    } catch {
        return fallback;
    }
}

function writeJsonAtomic(file, value) {
    const tmp = `${file}.tmp-${process.pid}`;
    const text = JSON.stringify(value, null, 2);
    writeFileSync(tmp, `${text}\n`, 'utf8');
    renameSync(tmp, file);
}

function appendJsonl(file, value) {
    appendFileSync(file, `${JSON.stringify(value)}\n`, 'utf8');
}

function nowIso() {
    return new Date().toISOString();
}

/** Session metadata snapshot (archived / bridge / subagent facts). */
const META_TTL_MS = Number(process.env.DSH_MESH_META_TTL_MS ?? 5000);
const sessionMetaCache = { at: 0, rows: new Map() };
function sessionMeta(sessionId) {
    const now = Date.now();
    if (now - sessionMetaCache.at > META_TTL_MS) {
        sessionMetaCache.at = now;
        sessionMetaCache.rows = new Map();
        const snapshot = readJson(join(MACHINE_DIR, 'sessions.json'), null);
        for (const row of snapshot?.sessions ?? []) {
            if (row && typeof row.sid === 'string') sessionMetaCache.rows.set(row.sid, row);
        }
    }
    return sessionMetaCache.rows.get(sessionId);
}

function refuseReason(sessionId) {
    if (typeof sessionId !== 'string' || sessionId.trim() === '') return 'target_required';
    if (/^(?:sub|child)-/.test(sessionId)) return 'subagent_target_unsupported';
    const meta = sessionMeta(sessionId);
    if (meta === undefined) return 'unknown_session';
    if (meta.is_bridge === true) return 'bridge_session';
    if (String(meta.state) === 'archived') return 'archived_session';
    return undefined;
}

/* ------------------------------------------------------------------ *
 * Journal + rate limit + holds
 * ------------------------------------------------------------------ */
/**
 * 账本按月切（评审第 4 条）：只增不减的文件迟早拖慢每次读。
 * 跨月第一次写入时把 `deliveries.jsonl` 改名成 `deliveries-YYYY-MM.jsonl`，再开当月新文件；
 * 历史文件一律保留，不自动删 —— 删审计是不可逆动作，得有人点头。
 */
let journalMonth = null;

function monthKeyOf(date) {
    return `${date.getUTCFullYear()}-${String(date.getUTCMonth() + 1).padStart(2, '0')}`;
}

function rotateJournalIfNeeded() {
    const current = monthKeyOf(new Date());
    if (journalMonth === current) return;
    try {
        if (existsSync(JOURNAL_FILE)) {
            const fileMonth = monthKeyOf(new Date(statSync(JOURNAL_FILE).mtimeMs));
            if (fileMonth !== current) {
                let target = join(MACHINE_DIR, `deliveries-${fileMonth}.jsonl`);
                let index = 1;
                while (existsSync(target)) {
                    target = join(MACHINE_DIR, `deliveries-${fileMonth}-${index}.jsonl`);
                    index += 1;
                }
                renameSync(JOURNAL_FILE, target);
                console.warn(`${PLUGIN} journal 跨月切档：${target}`);
            }
        }
    } catch (error) {
        console.warn(`${PLUGIN} journal rotate failed: ${describeError(error)}`);
    }
    journalMonth = current;
}

function journalLine(entry) {
    try {
        ensureDirs();
        rotateJournalIfNeeded();
        appendJsonl(JOURNAL_FILE, entry);
    } catch (error) {
        // Journal failures must not break delivery: report through the log only.
        console.warn(`${PLUGIN} journal append failed: ${describeError(error)}`);
    }
}

/** 拒收也进账本：status='refused'，与成功行同形，五件齐。 */
function auditRefusal(fields) {
    journalLine({
        ts: nowIso(),
        status: 'refused',
        presence: 'unknown',
        text_chars: 0,
        ...fields,
    });
}

function readJournalTail() {
    try {
        const candidates = [JOURNAL_FILE];
        try {
            const rotated = readdirSync(MACHINE_DIR)
                .filter((file) => /^deliveries-\d{4}-\d{2}(?:-\d+)?\.jsonl$/.test(file))
                .sort()
                .reverse();
            if (rotated.length > 0) candidates.push(join(MACHINE_DIR, rotated[0]));
        } catch {
            /* rotated lookup is best-effort */
        }
        const lines = [];
        for (const file of candidates) {
            if (!existsSync(file)) continue;
            const text = readFileSync(file, 'utf8');
            lines.push(...text.split('\n').filter((line) => line.trim() !== ''));
        }
        return lines.slice(-JOURNAL_MAX_SCAN).map((line) => {
            try {
                return JSON.parse(line);
            } catch {
                return null;
            }
        }).filter(Boolean);
    } catch {
        return [];
    }
}

/**
 * state 文件的键名要过 kb_check 第 13 项的校验（^[a-z][a-z0-9_]*$）。
 * 原先直接拼 `${from}->${to}`，会带 '>' 与 '-'，一旦投递就把
 * 40-协作\_machine\mesh-state.json 的 rate 写成非法键，整个自检当场变红
 * （2026-11-01 M59 / O34）。这里统一压成合法键，丢了可读性不算损失：
 * 键只用来数一小时内的次数，谁发给谁在 journal 里另有逐条记录。
 */
function rateKey(scope, a, b) {
    /*
     * O45-②：命名空间必须由代码给定，不能由自报字段决定。
     * 原先 `rateKey(from, to)` 与 `rateKey('target', to)` 拼法一样，`from` 又是自报的，
     * 谁写个 "target" 就撞进目标总量桶（一条消息烧两个目标额度，还能蹭 urgent 日闸）。
     * 现在第一段固定是 pair / target / urgent / hold，后面的自报值只能排在它后面。
     */
    const head = String(scope ?? '').trim() || 'key';
    /*
     * O45-② 补完（2026-11-02 M81）：中文发件名被压成下划线后彼此不可区分——
     * 「协作库维护」「主对话」「开发线」都会变成空串，pair 桶退化成「按目标计」，
     * 三条线共用一个 20 条/小时额度。非 ASCII 的自报值补 6 位哈希，桶就分得开。
     */
    const fingerprint = (part) => {
        const text = String(part ?? '');
        if (text === '' || /^[A-Za-z0-9_.-]+$/.test(text)) return '';
        return '_h' + createHash('sha1').update(text).digest('hex').slice(0, 6);
    };
    const tail = [[a, fingerprint(a)], [b, fingerprint(b)]]
        .filter(([part]) => part !== undefined && part !== null && String(part).trim() !== '')
        .map(([part, extra]) => `${String(part)}${extra}`)
        .join('_');
    const raw = `${head}_${tail}`.toLowerCase().replace(/[^a-z0-9_]+/g, '_').replace(/^_+|_+$/g, '');
    return /^[a-z]/.test(raw) ? raw : `r_${raw}`;
}

function rateAllowed(state, from, to, limit) {
    const key = rateKey('pair', from, to);
    const now = Date.now();
    const hourAgo = now - 60 * 60 * 1000;
    if (state.rate === null || typeof state.rate !== 'object') state.rate = {};
    const bucket = Array.isArray(state.rate[key]) ? state.rate[key].filter((ts) => ts > hourAgo) : [];
    if (bucket.length >= limit) {
        state.rate[key] = bucket;
        return { allowed: false, used: bucket.length };
    }
    bucket.push(now);
    state.rate[key] = bucket;
    return { allowed: true, used: bucket.length };
}

/**
 * 按「键 + 时间窗 + 上限」计数。与 rateAllowed 的区别是窗口与键都由调用方给：
 * 给目标总量闸用 60 条/小时（跨所有 from，防伪造发件人），给 urgent 日闸用 5 条/24 小时。
 */
function windowAllowed(state, key, windowMs, limit) {
    const now = Date.now();
    const since = now - windowMs;
    if (state.rate === null || typeof state.rate !== 'object') state.rate = {};
    const bucket = Array.isArray(state.rate[key]) ? state.rate[key].filter((ts) => ts > since) : [];
    state.rate[key] = bucket;
    if (bucket.length >= limit) return { allowed: false, used: bucket.length, limit };
    bucket.push(now);
    return { allowed: true, used: bucket.length, limit };
}

/* ------------------------------------------------------------------ *
 * Delivery
 * ------------------------------------------------------------------ */
function agentOptions(ctx) {
    try {
        const service = ctx.get('agentDefaultModel', false);
        const selection = typeof service?.currentSelection === 'function' ? service.currentSelection() : undefined;
        if (selection && typeof selection === 'object') {
            const options = {};
            if (typeof selection.provider === 'string') options.provider = selection.provider;
            if (typeof selection.model === 'string') options.model = selection.model;
            /*
             * O38 R4：`currentSelection()` 回的是 `{ provider, model, reasoningEffort? }`（宿主 ModelSelection），
             * 而 `agents.resume({ agentOptions })` 收的 AgentOptions 同样有 `reasoningEffort?: ReasoningEffortId`。
             * 原来只拷 provider/model，等于用户选的思考强度在「插件叫醒冷会话」这条路上被静默丢掉——
             * 会话照样起来，只是用默认强度跑，没有任何报错。这里照直传下去。
             */
            if (typeof selection.reasoningEffort === 'string' && selection.reasoningEffort.length > 0) {
                options.reasoningEffort = selection.reasoningEffort;
            }
            if (Object.keys(options).length > 0) return options;
        }
    } catch (error) {
        console.warn(`${PLUGIN} agentDefaultModel.currentSelection() failed: ${describeError(error)}`);
    }
    return undefined;
}

async function acquireAgent(ctx, sessionId) {
    // Live handle first: `runMaintenance` / `followup` live on the Agent the
    // Host keeps for an attached Session.
    const live = ctx.agents.get?.(sessionId);
    if (live !== undefined && live !== null) return { agent: live, handle: null, presence: 'live' };

    // Then the controller resolver (it revives an attached-but-cold Session).
    try {
        const controller = ctx.get('sessionController', false);
        if (controller && typeof controller.resolveAgent === 'function') {
            const resolved = await controller.resolveAgent(sessionId);
            /*
             * O38 R7：`sessionController.resolveAgent()` 的类型是 `{ agent } | { error: { message? } }`。
             * 原来写 `const agent = resolved?.agent ?? resolved`，出错时会把 `{ error }` 这个壳当成 agent
             * 继续往下判——虽然 `runMaintenance` 的检查让它落不进分支，但后果是**白跑一次 `agents.resume()`**，
             * 而且错误信息（`error.message`）被整条丢掉，日志里只留一句「resume 失败」。
             * 现在显式认出这种形态：记一行、打一句 warning，然后就当「这条路径没戏」继续往下（保留 resume 兜底，
             * 因为 resolveAgent 的 error 不必然意味着 resume 也会失败，但至少不再假装它是个 agent）。
             */
            if (resolved && typeof resolved === 'object' && resolved.error !== undefined && resolved.error !== null) {
                const detail = typeof resolved.error === 'object' && typeof resolved.error.message === 'string'
                    ? resolved.error.message
                    : String(resolved.error);
                journalLine({
                    ts: nowIso(), msg_id: '-', from: 'system', to: sessionId, mode: 'hold',
                    status: 'resolve_error',
                    note: 'sessionController.resolveAgent 返回了 {error}（不是 agent）：' + detail,
                });
                console.warn(`${PLUGIN} resolveAgent refused ${sessionId}: ${detail}（O38 R7：这不是 agent，别拿它当 agent）`);
            } else {
            const agent = resolved?.agent ?? resolved;
            if (agent && typeof agent.runMaintenance === 'function') {
                const lease = resolved?.handle ?? null;
                /*
                 * O38 R3：这条分支的 handle 可能为 null——`resolveAgent` 允许只回一个裸 Agent。
                 * 如果它其实复活了一个冷会话却没带 handle，我们就拿不到释放它的把手，
                 * 与「宿主已持有的 live」在返回值上无法区分（子代理审计：这条「无法证伪」）。
                 * 不去猜它，但把「谁在没租约的情况下把会话拉起来」记一行，别让它彻底静默。
                 */
                if (lease === null && ctx.agents?.get?.(sessionId) === undefined) {
                    journalLine({
                        ts: nowIso(), msg_id: '-', from: 'system', to: sessionId, mode: 'hold',
                        status: 'lease_unknown',
                        note: 'resolveAgent 返回了可用的 agent 但没带 handle，且 agents.get 里没有它 —— 这条会话可能被静默拉起（O38 R3，无法证伪）',
                    });
                }
                return { agent, handle: lease, presence: 'live-or-cold' };
            }
            }
        }
    } catch (error) {
        console.warn(`${PLUGIN} resolveAgent failed for ${sessionId}: ${describeError(error)}`);
    }

    // Finally a real cold resume, which yields a handle we can release later.
    const options = agentOptions(ctx);
    const handle = await ctx.agents.resume({
        resumeSessionId: sessionId,
        ...(options === undefined ? {} : { agentOptions: options }),
    });
    return { agent: handle.agent, handle, presence: 'cold' };
}

/**
 * Push one message into `agent`, using the maintenance gate when the Agent
 * exposes it (that is what makes the Host mark the turn as plugin-driven).
 *
 * 2026-11-01 M65（复核报告 R1/R2）：宿主 `runMaintenance()` 在目标 Agent
 * 非 idle 时会直接抛 `already has active work`（dsh-agent-loop 收口处硬校验），
 * 而 interrupt 的目标场景本来就是「对方正在跑」——无条件走 maintenance 会把
 * 这条最该成功的投递判失败。所以：识别「忙」这一种错，降级为直接 push，
 * 并把 `degraded` 标记留在返回值里；其它错误照旧上抛，不吞。
 */
function isBusyError(error) {
    const text = `${error?.name ?? ''} ${error?.message ?? error ?? ''}`.toLowerCase();
    return /active work|already has|in progress|busy/.test(text);
}

async function pushInto(agent, message, mode) {
    const push = () => {
        if (mode === 'interrupt' && typeof agent.steer === 'function') agent.steer(message);
        else if (mode === 'passive' && typeof agent.inject === 'function') agent.inject(message);
        else agent.followup(message);
    };
    if (typeof agent.runMaintenance === 'function') {
        let accepted = false;
        try {
            await agent.runMaintenance(() => {
                push();
                accepted = true;
                return Promise.resolve(true);
            });
            return accepted;
        } catch (error) {
            if (!isBusyError(error)) throw error;
            // 目标正在跑：让 maintenance 那一层让路，直接投。宿主不会把这一轮
            // 记成 plugin-driven（少一层标注），但比丢消息强。
            console.warn(`${PLUGIN} target busy, falling back to direct ${mode}: ${describeError(error)}`);
        }
    }
    if (typeof agent.followup !== 'function' && typeof agent.steer !== 'function') {
        throw new Error('target agent exposes no delivery method');
    }
    push();
    return true;
}

function buildMessage(text, fromSession) {
    const summary = `${PLUGIN} message from ${fromSession}: ${text.slice(0, 120)}`;
    const content = [{ type: 'text', text }];
    if (createUserMessage !== null) {
        try {
            return createUserMessage({
                content,
                source: { kind: SOURCE_KIND, form: NOTICE_FORM, summary, senderSessionId: fromSession },
            });
        } catch (error) {
            console.warn(`${PLUGIN} createUserMessage failed, falling back to plain object: ${describeError(error)}`);
        }
    }
    return {
        id: randomUUID(),
        role: 'user',
        content,
        source: { kind: SOURCE_KIND, form: NOTICE_FORM, summary, senderSessionId: fromSession },
    };
}

/**
 * Deliver one message. Never throws: every branch returns a plain object.
 */
async function deliver(ctx, runtime, request) {
    const started = Date.now();
    const to = String(request?.to ?? '').trim();
    const text = typeof request?.text === 'string' ? request.text : '';
    const requestedMode = String(request?.mode ?? 'queue');
    const mode = MODES.has(requestedMode) ? requestedMode : 'queue';
    const from = String(request?.from ?? 'unknown');
    const msgId = randomUUID();

    const record = (status, extra) => {
        const entry = {
            ts: nowIso(),
            msg_id: msgId,
            from,
            to,
            mode,
            status,
            elapsed_ms: Date.now() - started,
            ...(extra ?? {}),
        };
        journalLine(entry);
        runtime.record({ type: 'delivery', ...entry });
        return entry;
    };

    if (text.trim() === '') {
        auditRefusal({ msg_id: msgId, from, to, mode, reason: 'text_required' });
        return { accepted: false, reason: 'text_required', msg_id: msgId };
    }
    const refused = refuseReason(to);
    if (refused !== undefined) {
        // 撞墙也要留账：拒收行与成功行同形（2026-11-01 主对话评审第 2 条）。
        auditRefusal({ msg_id: msgId, from, to, mode, reason: refused });
        return { accepted: false, reason: refused, msg_id: msgId };
    }

    if (runtime.config.logOnly === true) {
        record('log_only', { text_chars: text.length });
        return { accepted: false, reason: 'log_only', msg_id: msgId, mode };
    }

    const urgent = request?.urgent === true;
    const state = loadState();
    const limit = Number.isFinite(runtime.config.ratePerHour) ? runtime.config.ratePerHour : 20;
    /*
     * 三道闸，顺序固定：
     * ① 目标总量 60 条/小时 —— 与 from 无关，因为 from 是自报的（评审第 5 条）；
     * ② urgent 走日闸 5 条/24 小时（评审第 6 条），非 urgent 走每对 20 条/小时；
     * ③ 任何一道撞墙都写账本（record 就是写一行 status=撞墙原因）。
     */
    let gate = windowAllowed(state, rateKey('target', to), 60 * 60 * 1000, TARGET_RATE_LIMIT);
    let gateReason = 'target_rate_limited';
    if (gate.allowed) {
        if (urgent) {
            gate = windowAllowed(state, rateKey('urgent', to), 24 * 60 * 60 * 1000, URGENT_DAILY_LIMIT);
            gateReason = 'urgent_daily_limited';
        } else {
            gate = rateAllowed(state, from, to, limit);
            gateReason = 'rate_limited';
        }
    }
    try {
        writeJsonAtomic(STATE_FILE, state);
    } catch (error) {
        /*
         * O45-⑤：state 写不进去时，限流计数只在内存里活一轮，60 条/小时的目标总量闸
         * 会静默 fail-open。写盘仍是 advisory、不拦投递，但必须留一行账，
         * 否则「闸被绕过」这件事谁都看不见。
         */
        journalLine({
            ts: nowIso(),
            msg_id: msgId,
            from,
            to,
            mode,
            status: 'state_write_failed',
            note: 'rate/holds 计数未能落盘，本小时内限流可能失效',
            error: describeError(error),
        });
    }
    if (!gate.allowed) {
        record(gateReason, { used: gate.used, limit: gate.limit ?? limit });
        return { accepted: false, reason: gateReason, msg_id: msgId, used: gate.used, limit: gate.limit ?? limit };
    }
    if (urgent) {
        // Bypass is audited, never silent: who skipped the per-pair gate and why.
        journalLine({
            ts: nowIso(),
            msg_id: msgId,
            from,
            to,
            mode,
            status: 'urgent_bypass',
            note: String(request?.urgentReason ?? 'caller marked urgent').slice(0, 200),
        });
    }

    let acquired;
    try {
        acquired = await acquireAgent(ctx, to);
    } catch (error) {
        record('failed', { stage: 'resolve', error: describeError(error) });
        return { accepted: false, reason: 'resolve_failed', error: describeError(error), msg_id: msgId };
    }

    const agent = acquired.agent;
    const sessionId = String(agent?.session?.id ?? to);
    const seqBefore = Number(agent?.session?.seq ?? 0);
    const message = buildMessage(text, from);

    /*
     * O63：先把「意图」落盘再动手。进程若在投递途中被杀，账本里留下一条
     * `pending`；启动时 retryPending 只认它（以及随后失败留下的 `failed`），
     * 成功行 `delivered` 一旦出现就永不再投。
     */
    record('pending', { text: String(text).slice(0, 4000) });

    let accepted = false;
    let deliveryError;
    try {
        accepted = await pushInto(agent, message, mode);
    } catch (error) {
        deliveryError = describeError(error);
    }

    const hold = acquired.handle;

    /*
     * O38 R3：插件正在卸载（teardown 已经清掉 sweep、还没清 holds）时落地的投递，
     * 如果把 handle 写进 holds，就再也没人扫它 —— 会话被永久拉起且不报错。
     * 这里立刻把 handle 还回去，用 'disposed' 明确拒绝，让调用方知道「不是对方没收，是这边关了」。
     */
    if (runtime.disposed && hold !== null && hold !== undefined) {
        try {
            await Promise.resolve(hold.dispose?.());
        } catch (error) {
            journalLine({ ts: nowIso(), msg_id: msgId, from: 'system', to: sessionId, mode: 'hold', status: 'release_failed', error: describeError(error) });
        }
        record('refused', { reason: 'disposed' });
        return { accepted: false, reason: 'disposed', msg_id: msgId };
    }

    /*
     * O38 R3：投递失败时不能把这个刚拿到的 cold handle 挂进 holds 让它白占 30 秒。
     * 失败一次就说明这条消息没进去，会话没有「保持 warm」的理由；立刻放回冷态，
     * 并留一行审计（否则「为什么会话被拉起来又放下」在账本里查不到）。
     */
    if (!accepted && hold !== null && hold !== undefined) {
        try {
            await hold.dispose?.();
            journalLine({
                ts: nowIso(), msg_id: msgId, from: 'system', to: sessionId, mode: 'hold',
                status: 'released', note: '投递失败，cold handle 立即释放（O38 R3）',
            });
        } catch (error) {
            journalLine({
                ts: nowIso(), msg_id: msgId, from: 'system', to: sessionId, mode: 'hold',
                status: 'release_failed', error: describeError(error),
            });
        }
    }

    /*
     * O38 R3：新投递走的是 live 路径（handle=null），而 holds 里还压着这个会话的旧 handle 时，
     * 老代码整块跳过，旧 handle 只能等它自己过期被 sweep 收。到点时若该 agent 正在跑回合，
     * 就会把会话冷翻（下一次 resume 可能撞 already has active work）。这里留一行账，
     * 至少让「谁握着一条过期租约」在 deliveries.jsonl 里查得到。
     */
    if (accepted && (hold === null || hold === undefined)) {
        const stale = runtime.holds.get(sessionId);
        if (stale !== undefined) {
            journalLine({
                ts: nowIso(), msg_id: msgId, from: 'system', to: sessionId, mode: 'hold',
                status: 'stale_lease', note: '本次投递走 live，holds 里仍有旧租约',
                stale_msg_id: stale.msgId, stale_expires_at: stale.expiresAt,
            });
        }
    }

    if (hold !== null && hold !== undefined && accepted) {
        const holdMs = Number.isFinite(runtime.config.holdMs) ? runtime.config.holdMs : DEFAULT_HOLD_MS;
        /*
         * O45-①：同一会话连着两条投递时，旧代码直接覆盖 Map 里的 handle，
         * 上一个 hold 既不 dispose 也不留 released 账 —— 「谁把这个会话从冷态拉起来又放下」
         * 这段历史就断了。覆盖前显式释放，并记一行 superseded。
         */
        const previous = runtime.holds.get(sessionId);
        if (previous !== undefined && previous.handle !== hold) {
            runtime.holds.delete(sessionId);
            // O38 R3：dispose 返回 Promise，`void` 掉后 rejection 不在 try/catch 内（unhandled rejection）；
            // 而且以前无论 dispose 成败都写 'released'，是假释放账。改成等它落地再按结果记账。
            const releaseNote = 'superseded by a newer delivery';
            try {
                await Promise.resolve(previous.handle?.dispose?.());
                journalLine({ ts: nowIso(), msg_id: previous.msgId, from: 'system', to: sessionId, mode: 'hold', status: 'released', note: releaseNote });
            } catch (error) {
                journalLine({ ts: nowIso(), msg_id: previous.msgId, from: 'system', to: sessionId, mode: 'hold', status: 'release_failed', error: describeError(error) });
            }
        }
        runtime.holds.set(sessionId, { handle: hold, expiresAt: Date.now() + holdMs, msgId });
    }

    if (!accepted) {
        record('failed', { stage: 'deliver', presence: acquired.presence, error: deliveryError });
        return { accepted: false, reason: 'deliver_failed', error: deliveryError, msg_id: msgId, presence: acquired.presence };
    }

    const seqAfter = Number(agent?.session?.seq ?? seqBefore);
    // O45-C：以前只记 text_chars，retryPending 拿不到正文，重投必被 text_required 挡回——
    // 「崩溃后补投」形同虚设。正文随行落盘（截 4000 字，与 hold 的上限一致）。
    /*
     * O63：成功投递记 `delivered`。以前这里写 `queued`，而 retryPending 又把
     * `queued` 当成「待重投」——每次插件加载都把已经投到过的信再投一遍，
     * 重投成功又写一条 `queued`，账本自己喂自己（维护线 2026-11-04 实测：
     * 20 分钟内同一封信被叫醒 20 次，账本里 `queued` 涨到 190 行）。
     * 状态名必须与语义对齐：`pending` 未确认 / `delivered` 已投到 / 其余是拒收或闸门。
     */
    record('delivered', {
        presence: acquired.presence,
        seq_before: seqBefore,
        seq_after: seqAfter,
        text_chars: text.length,
        text: String(text).slice(0, 4000),
    });

    if (mode === 'passive') {
        // Baseline is the seq AFTER the injection: injecting alone may advance it,
        // so only a later turn (a bigger seq) counts as "consumed".
        schedulePassiveUpgrade(ctx, runtime, { to, sessionId, baselineSeq: seqAfter, text, msgId });
    }

    // Two frames, because they mean different things to the browser half:
    // `queued` = work is in the target's inbox, refresh now (the new row often
    // shows up before the target's turn does); `delivered` = the target actually
    // idled after consuming it.
    runtime.broadcast({ type: 'queued', sessionId, msg_id: msgId, mode, at: nowIso() });
    if (mode !== 'passive') void announceDelivered(agent, runtime, sessionId, msgId, mode);

    return {
        accepted: true,
        msg_id: msgId,
        mode,
        presence: acquired.presence,
        sessionId,
        seq_before: seqBefore,
        seq_after: seqAfter,
    };
}

const DELIVERED_WAIT_MS = 180000;

async function announceDelivered(agent, runtime, sessionId, msgId, mode) {
    try {
        const idle = typeof agent?.whenIdle === 'function' ? agent.whenIdle() : null;
        if (idle !== null && idle !== undefined) {
            await Promise.race([idle, new Promise((resolve) => setTimeout(resolve, DELIVERED_WAIT_MS))]);
        }
        runtime.broadcast({ type: 'delivered', sessionId, msg_id: msgId, mode, at: nowIso() });
    } catch (error) {
        runtime.broadcast({ type: 'delivered', sessionId, msg_id: msgId, mode, error: describeError(error), at: nowIso() });
    }
}

/**
 * passive 的升级闹钟以前只在内存里（评审第 7 条）：宿主重启就丢，而且启动时不重扫，
 * 结果是「只塞不打断」变成了「悄悄丢」。现在把待升级项写进 mesh-state.json 的 holds，
 * 启动时扫一遍：过期的立刻补升级，没过期的接着等。
 */
function persistHold(payload) {
    try {
        const state = loadState();
        if (state.holds === undefined || state.holds === null || typeof state.holds !== 'object') state.holds = {};
        state.holds[rateKey('hold', payload.msgId)] = {
            to: payload.to,
            session_id: payload.sessionId,
            msg_id: payload.msgId,
            due_at: payload.dueAt,
            baseline_seq: payload.baselineSeq,
            /*
             * M81（2026-11-02）：正文只以 base64 落盘。直接存中文会让
             * `kb_check` 第 13 项报「值非 ASCII」——那条判据查的是**解析后的值**，
             * 用 JSON 的 \uXXXX 转义糊不过去（解析回来还是中文）。base64 解析后仍是 ASCII，
             * 判据干净，正文也不丢。
             */
            text_b64: Buffer.from(String(payload.text ?? ''), 'utf8').toString('base64'),
        };
        writeJsonAtomic(STATE_FILE, state);
    } catch (error) {
        console.warn(`${PLUGIN} hold persist failed: ${describeError(error)}`);
    }
}

function clearHold(msgId) {
    try {
        const state = loadState();
        if (state.holds === undefined || state.holds === null || typeof state.holds !== 'object') return;
        delete state.holds[rateKey('hold', msgId)];
        writeJsonAtomic(STATE_FILE, state);
    } catch (error) {
        console.warn(`${PLUGIN} hold clear failed: ${describeError(error)}`);
    }
}

function schedulePassiveUpgrade(ctx, runtime, payload) {
    const dueAt = Number.isFinite(payload.dueAt) ? payload.dueAt : Date.now() + PASSIVE_UPGRADE_MS;
    persistHold({ ...payload, dueAt });
    const timer = setTimeout(async () => {
        // O38 R3：这里原来只取 agent、把 handle 丢了。若这次是冷恢复（presence='cold'），
        // handle 不 dispose 就等于「为了投一条升级消息把会话永久拉起来」——宿主侧表现为
        // 会话常驻 warm、下次真投递可能撞 already has active work。handle 必须在 finally 里放。
        let acquired = null;
        try {
            acquired = await acquireAgent(ctx, payload.sessionId);
            const agent = acquired.agent;
            const seqNow = Number(agent?.session?.seq ?? 0);
            if (seqNow > payload.baselineSeq) {
                clearHold(payload.msgId);
                // M82：这条分支原来只清 hold、不留任何痕迹，人无法区分
                // 「被后续回合消费了」与「悄悄丢了」。补一行审计。
                journalLine({
                    ts: nowIso(),
                    msg_id: payload.msgId,
                    from: 'system',
                    to: payload.sessionId,
                    mode: 'passive',
                    status: 'superseded_by_activity',
                    note: 'passive 到期前目标已推进过回合，按「已被消费」处理，不再升级',
                    seq_now: seqNow,
                    baseline_seq: Number(payload.baselineSeq ?? 0),
                });
                return; // a later turn consumed it
            }
            // A fresh message: the passive one is still pending in the inbox, and
            // re-pushing the same object is rejected as "already pending".
            const upgradeText = `[passive 升级] 这条消息 10 分钟未被读取，已转为唤醒：\n${payload.text}`;
            await pushInto(agent, buildMessage(upgradeText, 'system:passive-upgrade'), 'queue');
            journalLine({
                ts: nowIso(),
                msg_id: payload.msgId,
                from: 'system',
                to: payload.to,
                mode: 'passive',
                status: 'upgraded_to_queue',
                note: 'passive message unread after 10 minutes',
            });
            runtime.broadcast({ type: 'upgraded', sessionId: payload.sessionId, msg_id: payload.msgId, at: nowIso() });
        } catch (error) {
            journalLine({
                ts: nowIso(),
                msg_id: payload.msgId,
                from: 'system',
                to: payload.to,
                mode: 'passive',
                status: 'upgrade_failed',
                error: describeError(error),
            });
        } finally {
            if (acquired !== null && acquired.handle !== null && acquired.handle !== undefined) {
                try {
                    await acquired.handle.dispose?.();
                    journalLine({
                        ts: nowIso(), msg_id: payload.msgId, from: 'system', to: payload.sessionId,
                        mode: 'hold', status: 'released',
                        note: 'passive 升级用的 cold handle 已释放（O38 R3）',
                    });
                } catch (error) {
                    journalLine({
                        ts: nowIso(), msg_id: payload.msgId, from: 'system', to: payload.sessionId,
                        mode: 'hold', status: 'release_failed', error: describeError(error),
                    });
                }
            }
            clearHold(payload.msgId);
            runtime.timers.delete(timer);
        }
    }, Math.max(0, dueAt - Date.now()));
    if (typeof timer.unref === 'function') timer.unref();
    // O45-D：升级 timer 以前不登记，插件卸载后它照样会醒来投一条「升级」消息。
    runtime.timers.add(timer);
}

/** 启动时把上次没升级完的 passive 捡回来（评审第 7 条）。 */
function restorePassiveHolds(ctx, runtime) {
    let state;
    try {
        state = loadState();
    } catch {
        return 0;
    }
    const holds = state?.holds;
    if (holds === undefined || holds === null || typeof holds !== 'object') return 0;
    let restored = 0;
    for (const value of Object.values(holds)) {
        if (value === null || typeof value !== 'object') continue;
        if (typeof value.msg_id !== 'string' || typeof value.session_id !== 'string') continue;
        const dueAt = Number.isFinite(value.due_at) ? value.due_at : Date.now();
        schedulePassiveUpgrade(ctx, runtime, {
            to: String(value.to ?? ''),
            sessionId: value.session_id,
            baselineSeq: Number.isFinite(value.baseline_seq) ? value.baseline_seq : 0,
            text: value.text_b64 === undefined || value.text_b64 === null
                ? String(value.text ?? '')
                : Buffer.from(String(value.text_b64), 'base64').toString('utf8'),
            msgId: value.msg_id,
            dueAt,
        });
        restored += 1;
    }
    if (restored > 0) console.warn(`${PLUGIN} 启动补扫：捡回 ${restored} 条待升级 passive`);
    return restored;
}

/* ------------------------------------------------------------------ *
 * Tool surface (three tools, nothing else)
 * ------------------------------------------------------------------ */
const DELIVERY_OUTPUT = {
    type: 'object',
    additionalProperties: true,
    properties: {
        accepted: { type: 'boolean', description: '是否已被接收' },
        msg_id: { type: 'string', description: '本次投递的 id（可用于 mesh_status）' },
        mode: { type: 'string', description: 'queue / interrupt / passive' },
        presence: { type: 'string', description: '目标是活会话还是冷会话' },
        reason: { type: 'string', description: '被拒绝时的原因' },
        sessionId: { type: 'string', description: '目标会话 id' },
    },
};

function toolDefinitions(agentCtx, hostCtx, runtime, defaultFrom) {
    return [
        makeTool({
            name: 'mesh_send',
            description: '把一条消息投递给另一个 Session 并（按模式）叫醒它。'
                + 'mode=queue 排队并在对方空闲时唤醒；mode=interrupt 插入对方当前回合；'
                + 'mode=passive 只放进对方收件箱、不叫醒（10 分钟未被消费会自动升级为唤醒）。'
                + '被拒绝时返回 accepted:false 与 reason，不会抛错。',
            parameters: {
                to: { type: 'string', description: '目标会话 id（session-… / social-…）', required: true },
                text: { type: 'string', description: '消息正文（纯文本）', required: true },
                mode: { type: 'string', enum: ['queue', 'interrupt', 'passive'], description: '投递模式，默认 queue' },
                from: { type: 'string', description: '发送方标识（可选，默认取当前会话）' },
                urgent: { type: 'boolean', description: '紧急通道：跳过每小时限流，但一定写审计行（默认 false）' },
                urgentReason: { type: 'string', description: '走紧急通道的原因（会记进账本）' },
            },
            output: {
                schema: DELIVERY_OUTPUT,
                render: (_args, value) => [{ type: 'text', text: JSON.stringify(value, null, 2) }],
            },
            execute: async (args) => {
                try {
                    const result = await deliver(hostCtx, runtime, {
                        to: args?.to,
                        text: args?.text,
                        mode: args?.mode,
                        from: args?.from ?? defaultFrom,
                        urgent: args?.urgent === true,
                        urgentReason: args?.urgentReason,
                    });
                    runtime.record({ type: 'tool', tool: 'mesh_send', result });
                    return result;
                } catch (error) {
                    // O45-B：这是唯一一处以前不写 journal 的失败分支——抛异常时账本上
                    // 什么也没有，事后完全看不出「那次投递为什么没到」。
                    auditRefusal({
                        msg_id: null,
                        from: args?.from ?? defaultFrom,
                        to: args?.to,
                        mode: args?.mode ?? 'queue',
                        reason: 'internal_error',
                        error: describeError(error),
                    });
                    return { accepted: false, reason: 'internal_error', error: describeError(error) };
                }
            },
        }),
        makeTool({
            name: 'mesh_status',
            description: '查一条投递的当前状态（journal 里的最后一条记录）。',
            parameters: {
                msg_id: { type: 'string', description: 'mesh_send 返回的 msg_id', required: true },
            },
            output: {
                schema: { type: 'object', additionalProperties: true },
                render: (_args, value) => [{ type: 'text', text: JSON.stringify(value, null, 2) }],
            },
            execute: async (args) => {
                try {
                    const msgId = String(args?.msg_id ?? '');
                    const rows = readJournalTail().filter((row) => row.msg_id === msgId);
                    if (rows.length === 0) return { found: false, msg_id: msgId };
                    return { found: true, msg_id: msgId, last: rows[rows.length - 1], history: rows.slice(-5) };
                } catch (error) {
                    return { found: false, error: describeError(error) };
                }
            },
        }),
        makeTool({
            name: 'mesh_inbox',
            description: '看某个会话最近的投递记录（默认当前会话）。',
            parameters: {
                session_id: { type: 'string', description: '要查看的会话 id（可选）' },
                limit: { type: 'number', description: '最多返回几条，默认 20' },
            },
            output: {
                schema: { type: 'object', additionalProperties: true },
                render: (_args, value) => [{ type: 'text', text: JSON.stringify(value, null, 2) }],
            },
            execute: async (args) => {
                try {
                    const target = String(args?.session_id ?? defaultFrom ?? '');
                    const limit = Number.isFinite(args?.limit) ? Math.max(1, Math.min(100, args.limit)) : 20;
                    const rows = readJournalTail().filter((row) => row.to === target);
                    return { session_id: target, count: rows.length, rows: rows.slice(-limit) };
                } catch (error) {
                    return { count: 0, error: describeError(error) };
                }
            },
        }),
    ];
}

function registerTools(agentCtx, hostCtx, runtime, defaultFrom) {
    return agentCtx.effect(() => {
        const disposers = [];
        for (const definition of toolDefinitions(agentCtx, hostCtx, runtime, defaultFrom)) {
            try {
                disposers.push(agentCtx.tools.register(definition));
            } catch (error) {
                console.warn(`${PLUGIN} tool register failed for ${definition.name}: ${describeError(error)}`);
            }
        }
        return () => {
            for (const disposer of disposers) {
                try {
                    disposer();
                } catch {
                    /* ignore */
                }
            }
        };
    }, `${PLUGIN}:tools`);
}

/* ------------------------------------------------------------------ *
 * HTTP routes: state / events (SSE) / log / send
 * ------------------------------------------------------------------ */
function writeJson(res, status, body) {
    res.writeHead(status, {
        'content-type': 'application/json; charset=utf-8',
        'cache-control': 'no-store',
    });
    res.end(JSON.stringify(body));
}

async function readBody(req, maxBytes = 64 * 1024) {
    const chunks = [];
    let size = 0;
    for await (const chunk of req) {
        size += chunk.length;
        if (size > maxBytes) throw new Error('body too large');
        chunks.push(chunk);
    }
    const text = Buffer.concat(chunks).toString('utf8');
    return text.trim() === '' ? {} : JSON.parse(text);
}

function installRoutes(ctx, runtime) {
    const webServer = ctx.get('webServer', false);
    if (webServer === undefined || webServer === null || typeof webServer.register !== 'function') {
        ctx.logger.info(`${PLUGIN}: no webserver composed; SSE routes not installed.`);
        return undefined;
    }
    const disposers = [];

    disposers.push(webServer.register({
        kind: 'exact',
        // M131 备注：/api/local-mesh/* 是历史遗留路径，与包名无耦合（client.js 按字面调用）——
        // 改名时不要顺手改成 /api/dsh-session-mesh/*，否则客户端整片 404。
        path: '/api/local-mesh/state',
        handler: (req, res) => {
            writeJson(res, 200, {
                config: {
                    logOnly: runtime.config.logOnly,
                    holdMs: runtime.config.holdMs,
                    ratePerHour: runtime.config.ratePerHour,
                    fallbackMs: runtime.config.fallbackMs,
                    tokenRequired: true,
                },
                clients: runtime.clients.size,
                holds: runtime.holds.size,
                journal: JOURNAL_FILE,
                events: EVENTS_FILE,
                at: nowIso(),
            });
        },
    }));

    disposers.push(webServer.register({
        kind: 'exact',
        path: '/api/local-mesh/events',
        handler: (req, res) => {
            res.writeHead(200, {
                'content-type': 'text/event-stream; charset=utf-8',
                'cache-control': 'no-store',
                connection: 'keep-alive',
            });
            res.write(`data: ${JSON.stringify({ type: 'ready', at: nowIso() })}\n\n`);
            runtime.clients.add(res);
            const heartbeat = setInterval(() => {
                try {
                    res.write(`: ping ${Date.now()}\n\n`);
                } catch {
                    /* the client is gone; the close handler will clean up */
                }
            }, 15000);
            if (typeof heartbeat.unref === 'function') heartbeat.unref();
            const drop = () => {
                clearInterval(heartbeat);
                runtime.clients.delete(res);
            };
            req.on('close', drop);
            res.on('close', drop);
        },
    }));

    disposers.push(webServer.register({
        kind: 'exact',
        path: '/api/local-mesh/log',
        handler: (req, res) => {
            if (req.method !== 'POST') {
                writeJson(res, 405, { code: 'method_not_allowed' });
                return;
            }
            void readBody(req)
                .then((body) => {
                    const entry = {
                        ts: nowIso(),
                        kind: 'client',
                        event: String(body?.event ?? 'unknown').slice(0, 64),
                        session_id: typeof body?.session_id === 'string' ? body.session_id : undefined,
                        detail: body?.detail,
                    };
                    try {
                        ensureDirs();
                        appendJsonl(EVENTS_FILE, entry);
                    } catch (error) {
                        writeJson(res, 500, { code: 'log_failed', message: describeError(error) });
                        return;
                    }
                    writeJson(res, 200, { ok: true });
                })
                .catch((error) => writeJson(res, 400, { code: 'bad_request', message: describeError(error) }));
        },
    }));

    disposers.push(webServer.register({
        kind: 'exact',
        path: '/api/local-mesh/send',
        handler: (req, res) => {
            if (req.method !== 'POST') {
                writeJson(res, 405, { code: 'method_not_allowed' });
                return;
            }
            // The listener is loopback-only, but a wake-up primitive still must not
            // be callable by any local process: require the per-process token.
            if (String(req.headers['x-mesh-token'] ?? '') !== runtime.config.token) {
                writeJson(res, 401, { code: 'unauthorized' });
                return;
            }
            void readBody(req)
                .then((body) => deliver(ctx, runtime, {
                    to: body?.to,
                    text: body?.text,
                    urgent: body?.urgent === true,
                    urgentReason: body?.urgentReason,
                    mode: body?.mode,
                    from: body?.from,
                }))
                .then((result) => writeJson(res, result.accepted ? 200 : 400, result))
                .catch((error) => {
                    // O45-B：HTTP 通道的失败同样要留痕，否则「投了但没到」查无此事。
                    auditRefusal({
                        msg_id: null,
                        from: body?.from,
                        to: body?.to,
                        mode: body?.mode ?? 'queue',
                        reason: 'internal_error',
                        error: describeError(error),
                    });
                    writeJson(res, 500, { accepted: false, error: describeError(error) });
                });
        },
    }));

    // O39：让外部（mesh.py / 人）在不重启宿主的条件下，命令插件重新给「已经活着的会话」
    // 注册工具。定时扫描已经每 5 秒做一次，这个路由是「立刻做一次并回报结果」的手动口。
    disposers.push(webServer.register({
        kind: 'exact',
        path: '/api/local-mesh/rescan',
        handler: (req, res) => {
            if (req.method !== 'POST') {
                writeJson(res, 405, { code: 'method_not_allowed' });
                return;
            }
            if (String(req.headers['x-mesh-token'] ?? '') !== runtime.config.token) {
                writeJson(res, 401, { code: 'unauthorized' });
                return;
            }
            const added = typeof runtime.scanRoots === 'function' ? runtime.scanRoots('http') : 0;
            let roots = 0;
            try {
                roots = ctx.get('agents', false)?.roots?.().length ?? 0;
            } catch {
                roots = -1;
            }
            writeJson(res, 200, { ok: true, registered_now: added, roots, tools: ['mesh_send', 'mesh_status', 'mesh_inbox'] });
        },
    }));

    return () => {
        for (const dispose of disposers) {
            try {
                dispose();
            } catch {
                /* ignore */
            }
        }
    };
}

/* ------------------------------------------------------------------ *
 * Startup retry of journaled-but-undelivered messages
 * ------------------------------------------------------------------ */
/*
 * O63（2026-11-04，维护线报「同一封信被叫醒 20 次」）：补投的判据要窄，且必须防自增殖。
 *
 *   1. 只认「未确认 / 失败」的末行：`pending`、`failed`。`refused` 与闸门行是
 *      **已裁定**的结果——原样重投必然被同一条规则再拒一次，只会制造噪声
 *      （O45-C 当初就是为了这个把没正文的旧行滤掉了）。要改这条口径，改
 *      RETRYABLE_STATUS 一处即可。
 *   2. 这条 msg 只要出现过任何一条「到过」的行，就永不再投。
 *      历史账本里 2026-11-03 之前的 `queued` 一律按「已投到」算（那时它就是成功语义）。
 *   3. 同一条 24 小时内至多重投 1 次（靠 `retry_attempt` 行记），每次加载最多 5 条。
 *      「重投成功→新行→再重投」的自增殖在这两条上被掐死。
 */
const RETRYABLE_STATUS = new Set(['pending', 'failed']);
const LANDED_STATUS = new Set(['delivered', 'queued', 'log_only', 'upgraded_to_queue', 'superseded_by_activity']);
const RETRY_COOLDOWN_MS = 24 * 60 * 60 * 1000;
const RETRY_MAX_PER_LOAD = 5;

/**
 * O46②：补投节奏从「加载后 5 秒一次」改成「退避翻倍」。
 * 第 n 轮（n 从 1 起）等 min(BASE * 2^(n-1), MAX)：5s → 10s → 20s → 40s → 80s → 160s → 320s → 600s 封顶。
 * 5 秒那个数当初是拍的；宿主刚起来时对端会话还没就绪，5 秒那一轮必失败、之后再也不投。
 */
const RETRY_BACKOFF_BASE_MS = 5000;
const RETRY_BACKOFF_MAX_MS = 10 * 60 * 1000;
/** 同一 msg 攒到这么多次尝试、且一次都没到过，就升级成 escalated，不再投。 */
const RETRY_ESCALATE_AFTER = 3;
/** 一轮里最多跑几个退避周期（跑满就停，别永久挂着）。 */
const RETRY_MAX_ROUNDS = 8;

/** 第 round 轮（1 起）的等待毫秒数；纯函数，便于反例测试。 */
export function retryBackoffMs(round) {
    const n = Number.isFinite(round) && round > 0 ? Math.floor(round) : 1;
    return Math.min(RETRY_BACKOFF_BASE_MS * 2 ** (n - 1), RETRY_BACKOFF_MAX_MS);
}

/** 某个 msg_id 已经尝试过几次补投（数 retry_attempt 行）。 */
export function countRetryAttempts(rows, msgId) {
    let n = 0;
    for (const row of rows) {
        if (row === null || typeof row !== 'object') continue;
        if (row.msg_id !== msgId) continue;
        if (row.status === 'retry_attempt') n += 1;
    }
    return n;
}

/**
 * 这个 msg 该不该升级（认输）：攒够 RETRY_ESCALATE_AFTER 次尝试、一次都没到过、还没升级过。
 * 注意它跟 pickRetryCandidates 是两条独立的路：候选受 24 小时冷却约束，
 * 而「认输」只看尝试次数——否则一封信要涨到第 3 次得等三天才看得见。
 */
export function shouldEscalate(rows, msgId) {
    let attempts = 0;
    let landed = false;
    let escalated = false;
    for (const row of rows) {
        if (row === null || typeof row !== 'object') continue;
        if (row.msg_id !== msgId) continue;
        if (row.status === 'retry_attempt') attempts += 1;
        if (LANDED_STATUS.has(row.status)) landed = true;
        if (row.status === 'escalated') escalated = true;
    }
    return !landed && !escalated && attempts >= RETRY_ESCALATE_AFTER;
}

/** 扫一遍账本，列出该升级的 msg_id（去重、保序）。 */
export function pickEscalations(rows) {
    const seen = new Set();
    const out = [];
    for (const row of rows) {
        if (row === null || typeof row !== 'object') continue;
        const msgId = typeof row.msg_id === 'string' ? row.msg_id : '';
        if (msgId === '' || seen.has(msgId)) continue;
        seen.add(msgId);
        if (shouldEscalate(rows, msgId)) out.push(msgId);
    }
    return out;
}

/** 这个 msg 是不是已经升级过（读过 escalated 就不再投）。 */
export function isEscalated(rows, msgId) {
    for (const row of rows) {
        if (row === null || typeof row !== 'object') continue;
        if (row.msg_id !== msgId) continue;
        if (row.status === 'escalated') return true;
    }
    return false;
}

/**
 * 从账本行里挑出「该补投」的候选。纯函数，便于反例测试。
 * @param {Array<object>} rows journal 行（顺序不限）
 * @param {number} now 当前毫秒
 * @param {number} limit 本次最多几条
 */
export function pickRetryCandidates(rows, now = Date.now(), limit = RETRY_MAX_PER_LOAD) {
    const byMsg = new Map();
    for (const row of rows) {
        if (row === null || typeof row !== 'object') continue;
        const msgId = typeof row.msg_id === 'string' ? row.msg_id : '';
        if (msgId === '') continue;
        if (row.from === 'system') continue;
        const list = byMsg.get(msgId);
        if (list === undefined) byMsg.set(msgId, [row]);
        else list.push(row);
    }
    const picked = [];
    for (const [msgId, list] of byMsg) {
        list.sort((a, b) => (Date.parse(a.ts) || 0) - (Date.parse(b.ts) || 0));
        const last = list[list.length - 1];
        if (last === undefined || !RETRYABLE_STATUS.has(last.status)) continue;
        if (list.some((row) => LANDED_STATUS.has(row.status))) continue;
        const retriedRecently = list.some((row) => {
            if (row.status !== 'retry_attempt') return false;
            const at = Date.parse(row.ts);
            return Number.isFinite(at) && now - at < RETRY_COOLDOWN_MS;
        });
        if (retriedRecently) continue;
        const text = list.map((row) => row.text).find((value) => typeof value === 'string' && value.trim() !== '');
        if (text === undefined) continue;
        const at = Date.parse(last.ts);
        if (!Number.isFinite(at) || now - at >= RETRY_COOLDOWN_MS) continue;
        picked.push({ msg_id: msgId, to: last.to, from: last.from, mode: last.mode ?? 'queue', text, at });
    }
    picked.sort((a, b) => a.at - b.at);
    return picked.slice(-limit);
}

function retryPending(ctx, runtime) {
    let rows = [];
    try {
        rows = readJournalTail();
    } catch {
        return;
    }
    const escalated = new Set(pickEscalations(rows));
    for (const msgId of escalated) {
        const last = rows.filter((row) => row !== null && typeof row === 'object' && row.msg_id === msgId).pop() ?? {};
        const attempts = countRetryAttempts(rows, msgId);
        // 同类连续失败到顶：写一条 escalated 收尾，不再每天捞一次。这条是给人看的。
        journalLine({
            ts: nowIso(),
            msg_id: msgId,
            from: last.from,
            to: last.to,
            mode: 'queue',
            status: 'escalated',
            attempts,
            note: 'retry gave up after ' + attempts + ' attempts (O46②): the target never confirmed',
        });
        console.warn(`${PLUGIN} retry escalated ${msgId} after ${attempts} attempts -> ${String(last.to)}`);
    }
    for (const candidate of pickRetryCandidates(rows)) {
        if (escalated.has(candidate.msg_id) || isEscalated(rows, candidate.msg_id)) continue;
        // 先记「这次尝试」再动手：即使投递途中再崩一次，也不会在冷却期内重复投。
        journalLine({
            ts: nowIso(),
            msg_id: candidate.msg_id,
            from: candidate.from,
            to: candidate.to,
            mode: 'queue',
            status: 'retry_attempt',
            note: 'startup retry of an unconfirmed delivery',
        });
        void deliver(ctx, runtime, { to: candidate.to, text: candidate.text, mode: 'queue', from: candidate.from })
            .catch(() => {});
    }
}

/* ------------------------------------------------------------------ *
 * Plugin entry
 * ------------------------------------------------------------------ */
export async function apply(ctx, config) {
    // O38 R5 补：schema 不拒绝未知键，这里把「拼错的键」点名报出来，别让它静默用默认值。
    // 注意：schema 拿不到时 Config 是 undefined（不是 null），这里必须能走通。
    const knownKeys = new Set(Config && Config.dict ? Object.keys(Config.dict) : CONFIG_KEYS);
    const unknownKeys = Object.keys(config ?? {}).filter((k) => !knownKeys.has(k));
    if (unknownKeys.length > 0) {
        ctx.logger.warn(`${PLUGIN} 配置里有不认识的键：${unknownKeys.join(', ')}（认识的只有 ${[...knownKeys].join(', ')}）——拼错的键会静默用默认值，请核对 cordis.patch.yml`);
    }
    const runtimeConfig = {
        logOnly: config?.logOnly !== false,
        // Defaults argued in the design review (2.txt): a 10-minute hold can keep a
        // Session "live" in the state machine and turns a failed self-heal into a
        // delayed disappearance, so hold briefly first and climb the ladder later.
        holdMs: Number.isFinite(config?.holdMs) ? config.holdMs : DEFAULT_HOLD_MS,
        // 3/hour is too tight for the federal/company target (one CEO delegating 4
        // tasks trips it); `urgent: true` bypasses the gate and is always audited.
        ratePerHour: Number.isFinite(config?.ratePerHour) ? config.ratePerHour : 20,
        fallbackMs: Number.isFinite(config?.fallbackMs) ? config.fallbackMs : 60000,
        token: randomUUID(),
    };
    const runtime = {
        config: runtimeConfig,
        clients: new Set(),
        holds: new Map(),
        timers: new Set(),
        /* O45-⑦：每个 agent 的工具注册都要留一个撤消句柄，插件卸载时才能收干净。 */
        toolDisposers: [],
        events: [],
        record(entry) {
            runtime.events.push(entry);
            if (runtime.events.length > 200) runtime.events.splice(0, runtime.events.length - 200);
        },
        broadcast(frame) {
            const payload = `data: ${JSON.stringify(frame)}\n\n`;
            for (const res of runtime.clients) {
                try {
                    res.write(payload);
                } catch {
                    runtime.clients.delete(res);
                }
            }
            try {
                ensureDirs();
                appendJsonl(EVENTS_FILE, { ts: nowIso(), kind: 'host', ...frame });
            } catch {
                /* logging is best effort */
            }
        },
    };

    try {
        const hostTools = await import('@deepseek-ai/dsh-tools');
        if (typeof hostTools.defineTool === 'function') {
            defineTool = hostTools.defineTool;
            defineToolOrigin = 'host:@deepseek-ai/dsh-tools';
        }
    } catch {
        defineTool = null;
    }

    try {
        const hostLlm = await import('@deepseek-ai/dsh-llm');
        if (typeof hostLlm.createUserMessage === 'function') {
            createUserMessage = hostLlm.createUserMessage;
            messageOrigin = 'host:@deepseek-ai/dsh-llm';
        }
    } catch {
        createUserMessage = null;
    }

    ensureDirs();
    // POST /send is a debug/test surface; the token is shared with local callers
    // through a file. 2026-11-01 评审第 3 条：不再写在协作库的 _machine 下（会随库备份走），
    // 默认落到 DSH 自己的目录；旧位置的残留文件由调用方自行删掉。
    // 2026-11-04 事故：测试里用假 ctx 调了一次 apply()，它照样把新 token 写进真文件，
    // 把运行中实例的 token 覆盖掉 ⇒ 之后所有 mesh.py 调用 401（运行中的插件只在内存里
    // 认自己那份）。三个口子：① DSH_MESH_TOKEN_FILE 指定别处写；② DSH_MESH_NO_TOKEN_WRITE=1
    // 直接不写（单测就该用它）；③ 默认行为不变（真宿主加载时轮换 token 并写盘）。
    const tokenWriteTarget = process.env.DSH_MESH_TOKEN_FILE || TOKEN_FILE;
    const tokenWriteAllowed = process.env.DSH_MESH_NO_TOKEN_WRITE !== '1';
    let tokenFileStatus = tokenWriteAllowed ? `written:${tokenWriteTarget}` : 'skipped (DSH_MESH_NO_TOKEN_WRITE=1)';
    if (tokenWriteAllowed) {
        try {
            mkdirSync(dirname(tokenWriteTarget), { recursive: true });
            writeFileSync(tokenWriteTarget, runtimeConfig.token, 'utf8');
        } catch (error) {
            tokenFileStatus = `failed: ${describeError(error)}`;
        }
    }
    ctx.logger.info(`${PLUGIN}: loaded (defineTool=${defineToolOrigin}, message=${messageOrigin}, logOnly=${runtimeConfig.logOnly}, holdMs=${runtimeConfig.holdMs}, tokenFile=${tokenFileStatus})`);

    // Tools are registered per root agent: existing ones now, future ones on event.
    const registered = new WeakSet();
    const registerOne = (agent) => {
        if (agent === undefined || agent === null || registered.has(agent)) return;
        try {
            if (typeof ctx.agents.roots === 'function' && !ctx.agents.roots().includes(agent)) return;
        } catch {
            return;
        }
        registered.add(agent);
        try {
            const defaultFrom = String(agent?.session?.id ?? agent?.sessionId ?? 'unknown');
            const disposeTools = registerTools(agent.ctx, ctx, runtime, defaultFrom);
            if (typeof disposeTools === 'function') runtime.toolDisposers.push(disposeTools);
        } catch (error) {
            console.warn(`${PLUGIN} registerTools failed: ${describeError(error)}`);
        }
    };
    const stopCreated = ctx.on('agent/created', ({ agent }) => {
        registerOne(agent);
        return undefined;
    });
    // O39（2026-11-01 M68）：只在 load 时扫一次 roots + 依赖 agent/created 事件是不够的。
    // 宿主启动时 roots() 是空的；而 agent 是「会话被唤醒时才创建」，并且插件 ctx 收到的
    // 事件受 scope 过滤，`agent/created` 不一定送到这里 —— 于是重启后继续用的会话
    // （包括本会话）永远不会有 mesh_* 工具。改成一个便宜的多路径兜底：定时扫 + HTTP rescan。
    const scanRoots = (label) => {
        let added = 0;
        try {
            for (const existing of ctx.agents.roots()) {
                if (existing === undefined || existing === null || registered.has(existing)) continue;
                registerOne(existing);
                added += 1;
            }
        } catch (error) {
            console.warn(`${PLUGIN} roots scan failed (${label}): ${describeError(error)}`);
        }
        return added;
    };
    runtime.scanRoots = scanRoots;
    scanRoots('load');
    const toolScan = setInterval(() => {
        scanRoots('tick');
    }, TOOL_SCAN_MS);
    if (typeof toolScan.unref === 'function') toolScan.unref();

    // passive 待升级项在 state 里，重启后补扫一次（评审第 7 条）。
    try {
        restorePassiveHolds(ctx, runtime);
    } catch (error) {
        console.warn(`${PLUGIN} restorePassiveHolds failed: ${describeError(error)}`);
    }


    const routeDispose = installRoutes(ctx, runtime);

    const sweep = setInterval(() => {
        const now = Date.now();
        for (const [sessionId, hold] of runtime.holds) {
            if (hold.expiresAt > now) continue;
            runtime.holds.delete(sessionId);
            // O38 R3：dispose 的 rejection 必须在同一个 catch 里落地，且只有成功才写 'released'。
            Promise.resolve(hold.handle?.dispose?.()).then(
                () => journalLine({ ts: nowIso(), msg_id: hold.msgId, from: 'system', to: sessionId, mode: 'hold', status: 'released' }),
                (error) => journalLine({ ts: nowIso(), msg_id: hold.msgId, from: 'system', to: sessionId, mode: 'hold', status: 'release_failed', error: describeError(error) }),
            );
        }
    }, HOLD_SWEEP_MS);
    if (typeof sweep.unref === 'function') sweep.unref();

    // O46②：不是「5 秒一次就走」，而是按 5s→10s→…→600s 封顶退避重试，跑满 RETRY_MAX_ROUNDS 轮收手。
    let retryRound = 0;
    const scheduleRetry = () => {
        const delay = retryBackoffMs(retryRound + 1);
        const timer = setTimeout(() => {
            retryRound += 1;
            try {
                retryPending(ctx, runtime);
            } catch (error) {
                console.warn(`${PLUGIN} retry pending failed: ${describeError(error)}`);
            }
            if (retryRound < RETRY_MAX_ROUNDS) {
                runtime.retryTimer = scheduleRetry();
            }
        }, delay);
        if (typeof timer.unref === 'function') timer.unref();
        runtime.retryTimer = timer;
        return timer;
    };
    const retry = scheduleRetry();

    return async () => {
        // O38 R3：先立「已销毁」旗。deliver 在拿到 handle 后会复查它——否则 teardown 清完 sweep、
        // 还没清 holds 的那一小段里落地的在飞投递，会把 handle 写进一个再也不会被扫的 Map（永久漏）。
        runtime.disposed = true;
        clearInterval(sweep);
        clearTimeout(retry);
        if (runtime.retryTimer !== undefined && runtime.retryTimer !== retry) clearTimeout(runtime.retryTimer);
        // O45-D：把所有未到点的 passive 升级 timer 一起撤掉。
        for (const timer of runtime.timers) clearTimeout(timer);
        runtime.timers.clear();
        // O45-⑦：撤掉各 agent 上的工具注册，否则热重载会撞 dsh-tools 的 duplicate factory。
        for (const disposeTools of runtime.toolDisposers) {
            try {
                disposeTools();
            } catch (error) {
                console.warn(`${PLUGIN} tool dispose failed: ${describeError(error)}`);
            }
        }
        runtime.toolDisposers.length = 0;
        for (const res of runtime.clients) {
            try {
                res.end();
            } catch {
                /* ignore */
            }
        }
        runtime.clients.clear();
        for (const [sessionId, hold] of runtime.holds) {
            // O38 R3：这里原来 try/catch 包着 `void dispose()`——同步异常能抓、Promise rejection 抓不到。
            try {
                await Promise.resolve(hold.handle?.dispose?.());
            } catch (error) {
                journalLine({ ts: nowIso(), msg_id: hold.msgId, from: 'system', to: sessionId, mode: 'hold', status: 'release_failed', error: describeError(error) });
            }
            // Anything still pending belongs to a disabled plugin: mark it orphaned
            // so a later re-enable never replays old mail.
            journalLine({
                ts: nowIso(),
                msg_id: hold.msgId,
                from: 'system',
                to: sessionId,
                mode: 'hold',
                status: 'orphaned',
                note: 'plugin disposed before the hold expired; not replayed',
            });
        }
        runtime.holds.clear();
        try {
            routeDispose?.();
        } catch {
            /* ignore */
        }
        try {
            await stopCreated?.();
        } catch {
            /* ignore */
        }
        ctx.logger.info(`${PLUGIN}: disposed.`);
    };
}
