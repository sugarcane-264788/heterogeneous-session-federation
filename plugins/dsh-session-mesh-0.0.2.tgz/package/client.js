/**
 * dsh-session-mesh — Web (browser) half.
 *
 * Two jobs:
 *   1. Listen to `/api/local-mesh/events` (SSE, emitted by the Host half of this
 *      same bundle) and call `ctx.sessions.refresh()` as soon as a Session has
 *      been woken or messaged by the plugin. Without this, a plugin-woken
 *      Session never reaches the sidebar until the user presses F12 or the
 *      connection is re-established by hand.
 *   2. Keep a slow safety net: refresh once a minute while the tab is visible,
 *      so even a missed SSE frame cannot leave the sidebar stale forever.
 *
 * `logOnly` (read from the Host half's `/api/local-mesh/state`) turns this into
 * an observer: it records every frame to `build\mesh-events.jsonl` through
 * `/api/local-mesh/log` but never touches the sidebar. That is how we prove
 * which frames actually arrive before trusting them.
 */
window.__ModuleLoader__.load({
    // id 必须与 package.json 的 name 完全一致：DSH 客户端模块表按包名建行，
    // 写成短名会让加载器找不到该行、把同一脚本再执行一次，第二次 register 抛
    // "duplicate factory registration"，整台界面起不来（2026-11-01 事故）。
    id: '@local/session-mesh-lite',
    factory(require) {
        const React = require('react');

        const PLUGIN = '[session-mesh-lite]';
        const NS = 'session-mesh-lite';
        const REFRESH_DEBOUNCE_MS = 300;
        const FALLBACK_POLL_MS = 60000;
        const RECONNECT_MIN_MS = 1000;
        const RECONNECT_MAX_MS = 30000;

        const DICT = {
            en: {
                failed: '会话网格：投递失败',
                delivered: '会话网格：已投递',
                upgraded: '会话网格：被动消息已升级为唤醒',
            },
            zh: {
                failed: '会话网格：投递失败',
                delivered: '会话网格：已投递',
                upgraded: '会话网格：被动消息已升级为唤醒',
            },
        };

        function log(line) {
            try {
                console.debug(`${PLUGIN} ${line}`);
            } catch {
                /* console may be unavailable in odd embeddings */
            }
        }

        async function fetchState() {
            try {
                const response = await fetch('/api/local-mesh/state', { headers: { accept: 'application/json' } });
                if (!response.ok) return undefined;
                return await response.json();
            } catch {
                return undefined;
            }
        }

        function postLog(event, detail, sessionId) {
            try {
                void fetch('/api/local-mesh/log', {
                    method: 'POST',
                    headers: { 'content-type': 'application/json' },
                    body: JSON.stringify({ event, detail, session_id: sessionId }),
                }).catch(() => {});
            } catch {
                /* logging is best effort */
            }
        }

        return {
            inject: ['slots', 'locale', 'sessions', 'timer', 'remote', 'remote.session'],

            apply(ctx) {
                ctx.effect(() => {
                    let disposed = false;
                    let fallbackMs = FALLBACK_POLL_MS;
                    let source = null;
                    let reconnectTimer = null;
                    let reconnectDelay = RECONNECT_MIN_MS;
                    let refreshTimer = null;
                    let fallbackTimer = null;
                    let logOnly = true;
                    let lastFrameAt = 0;
                    let refreshCount = 0;

                    const refreshNow = (why) => {
                        try {
                            ctx.sessions.refresh();
                            refreshCount += 1;
                            log(`refresh #${refreshCount} (${why})`);
                            postLog('refresh', why);
                        } catch (error) {
                            log(`refresh failed: ${error && error.message ? error.message : error}`);
                            postLog('refresh_failed', String(error));
                        }
                    };

                    const scheduleRefresh = (why) => {
                        if (logOnly) return;
                        if (refreshTimer !== null) return;
                        refreshTimer = ctx.timeout(() => {
                            refreshTimer = null;
                            if (!disposed) refreshNow(why);
                        }, REFRESH_DEBOUNCE_MS);
                    };

                    const handleFrame = (frame) => {
                        lastFrameAt = Date.now();
                        const type = typeof frame?.type === 'string' ? frame.type : 'unknown';
                        if (type === 'ready') {
                            log('sse ready');
                            postLog('ready');
                            return;
                        }
                        log(`frame ${type} session=${frame?.sessionId ?? '-'} msg=${frame?.msg_id ?? '-'}`);
                        postLog(type, frame?.mode ?? frame?.reason ?? null, frame?.sessionId);
                        if (type === 'queued' || type === 'delivered' || type === 'upgraded') {
                            scheduleRefresh(`sse:${type}`);
                        }
                    };

                    const connect = () => {
                        if (disposed) return;
                        try {
                            source = new EventSource('/api/local-mesh/events');
                        } catch (error) {
                            log(`EventSource failed: ${error && error.message ? error.message : error}`);
                            scheduleReconnect();
                            return;
                        }
                        source.onmessage = (messageEvent) => {
                            reconnectDelay = RECONNECT_MIN_MS;
                            let frame;
                            try {
                                frame = JSON.parse(messageEvent.data);
                            } catch {
                                return;
                            }
                            handleFrame(frame);
                        };
                        source.onopen = () => {
                            log('sse open');
                            reconnectDelay = RECONNECT_MIN_MS;
                        };
                        source.onerror = () => {
                            log('sse error');
                            postLog('sse_error');
                            try {
                                source?.close();
                            } catch {
                                /* ignore */
                            }
                            source = null;
                            scheduleReconnect();
                        };
                    };

                    const scheduleReconnect = () => {
                        if (disposed || reconnectTimer !== null) return;
                        const delay = reconnectDelay;
                        reconnectDelay = Math.min(RECONNECT_MAX_MS, Math.round(reconnectDelay * 1.8));
                        reconnectTimer = ctx.timeout(() => {
                            reconnectTimer = null;
                            connect();
                        }, delay);
                    };

                    void fetchState().then((state) => {
                        if (disposed) return;
                        logOnly = state?.config?.logOnly !== false;
                        const configured = Number(state?.config?.fallbackMs);
                        if (Number.isFinite(configured) && configured >= 5000 && configured <= 300000) {
                            fallbackMs = configured;
                        }
                        log(`mode=${logOnly ? 'log-only' : 'active'} holdMs=${state?.config?.holdMs ?? '-'} fallbackMs=${fallbackMs}`);
                        postLog('mode', logOnly ? 'log-only' : 'active');
                        connect();
                    });

                    // Safety net: one quiet refresh per minute while the tab is visible.
                    fallbackTimer = ctx.interval(() => {
                        if (disposed) return;
                        if (document.visibilityState === 'hidden') return;
                        const stale = Date.now() - lastFrameAt;
                        if (stale < fallbackMs) return;
                        scheduleRefresh('fallback');
                    }, FALLBACK_POLL_MS);

                    log('client ready');

                    return () => {
                        disposed = true;
                        for (const timer of [refreshTimer, reconnectTimer, fallbackTimer]) {
                            if (timer !== null) {
                                try {
                                    timer();
                                } catch {
                                    /* ignore */
                                }
                            }
                        }
                        refreshTimer = null;
                        reconnectTimer = null;
                        fallbackTimer = null;
                        try {
                            source?.close();
                        } catch {
                            /* ignore */
                        }
                        source = null;
                        log('client disposed');
                    };
                }, `${PLUGIN}:bridge`);

                ctx.locale.register(NS, DICT);

                // A tiny status chip next to the manual refresh button: it tells the
                // user whether the bridge is live, so a silent failure is visible.
                ctx.slots.inject('sidebar.footer.action', () => {
                    const [status, setStatus] = React.useState({ mode: '…', frames: 0, last: 0 });
                    React.useEffect(() => {
                        const read = () => {
                            const stamp = Date.now();
                            setStatus((previous) => ({ ...previous, last: stamp }));
                        };
                        const timer = setInterval(read, 5000);
                        return () => clearInterval(timer);
                    }, []);
                    return React.createElement(
                        'span',
                        {
                            title: ctx.locale.t(NS, 'delivered'),
                            style: {
                                display: 'inline-flex',
                                alignItems: 'center',
                                gap: '4px',
                                marginInline: '6px',
                                fontSize: '11px',
                                opacity: 0.72,
                                cursor: 'default',
                            },
                            // M131 备注：这个 data-testid 是历史遗留标识，与包名无耦合——
                            // 改名（@local/* -> dsh-*）时不要顺手改它，改了会让既有 UI 测试与探针失效。
                            'data-testid': 'session-mesh-lite-chip',
                        },
                        React.createElement('span', {
                            style: {
                                width: '6px',
                                height: '6px',
                                borderRadius: '50%',
                                background: status.last > 0 ? 'var(--dsw-alias-state-success-primary)' : 'var(--dsw-alias-state-warning-primary)',
                            },
                        }),
                        React.createElement('span', null, status.mode),
                    );
                });
            },
        };
    },
});
